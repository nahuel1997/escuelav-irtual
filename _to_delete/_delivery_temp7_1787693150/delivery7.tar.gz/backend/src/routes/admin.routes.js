const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin.controller');
const testingController = require('../controllers/testing.controller');
const mailsController = require('../controllers/mails.controller');
const { requireAuth, requireRole } = require('../middlewares/auth.middleware');
const { uploadImagen } = require('../middlewares/upload.middleware');

// Todo /api/admin/* requiere estar logueado Y tener rol admin.
router.use(requireAuth, requireRole('admin'));

router.get('/dashboard', adminController.getDashboard);

router.get('/users', adminController.listUsersByRole);
router.post('/users', adminController.createUser);

router.get('/courses', adminController.listCourses);
router.post('/courses', adminController.createCourse);
router.put('/courses/:id', adminController.updateCourse);

router.get('/content', adminController.listContent);
router.put('/content/:clave', adminController.updateContent);

router.post('/upload-imagen', uploadImagen, adminController.uploadImage);

router.get('/calendario', adminController.listCalendarEvents);

router.get('/nav-links', adminController.listNavLinks);
router.post('/nav-links', adminController.createNavLink);
router.put('/nav-links/:id', adminController.updateNavLink);
router.delete('/nav-links/:id', adminController.deleteNavLink);

router.get('/botones', adminController.listButtonOptions);
router.post('/botones', adminController.createButtonOption);
router.put('/botones/:id', adminController.updateButtonOption);
router.delete('/botones/:id', adminController.deleteButtonOption);

router.get('/errores', adminController.listErrorLogs);
router.delete('/errores', adminController.clearErrorLogs);

router.get('/logins', adminController.listLoginLogs);

// Registro de chats de soporte (solo lectura — ver support.routes.js para
// el panel donde de verdad se responde).
router.get('/chats', adminController.listChats);
router.get('/chats/:id/mensajes', adminController.listChatMessages);

// Entorno de mails (/admin-panel/mails): plantillas, configuración,
// listas de mailing y registro de envíos — ver mails.controller.js.
router.get('/mails/plantillas', mailsController.listTemplates);
router.put('/mails/plantillas/:clave', mailsController.updateTemplate);
router.post('/mails/plantillas/:clave/probar', mailsController.testSend);

router.get('/mails/configuracion', mailsController.listSettings);
router.put('/mails/configuracion/:clave', mailsController.updateSetting);

router.get('/mails/registro', mailsController.listLog);

router.get('/mails/listas', mailsController.listLists);
router.post('/mails/listas', mailsController.createList);
router.put('/mails/listas/:id', mailsController.updateList);
router.delete('/mails/listas/:id', mailsController.deleteList);
router.get('/mails/listas/:id/miembros', mailsController.listMembers);
router.post('/mails/listas/:id/miembros', mailsController.addMember);
router.post('/mails/listas/:id/miembros/todos', mailsController.addTodos);
router.delete('/mails/listas/:id/miembros/todos', mailsController.removeTodos);
router.delete('/mails/listas/:id/miembros/:userId', mailsController.removeMember);
router.post('/mails/listas/:id/enviar', mailsController.sendToList);

// Entorno de testing (corre la suite de Jest a pedido — ver
// testing.controller.js para el detalle de por qué es seguro).
router.get('/testing/suites', testingController.listSuites);
router.post('/testing/run/:id', testingController.runSuite);

module.exports = router;
