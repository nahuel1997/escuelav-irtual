const db = require('../config/db');

function listAll({ categoria, estado } = {}) {
  const query = db('courses').select('*').orderBy('created_at', 'desc');
  if (categoria) query.where({ categoria });
  if (estado) query.where({ estado });
  return query;
}

function findById(id) {
  return db('courses').where({ id }).first();
}

function create(data) {
  return db('courses').insert(data);
}

function listByProfesor(profesorId) {
  return db('courses').where({ profesor_id: profesorId }).orderBy('created_at', 'desc');
}

function update(id, data) {
  return db('courses').where({ id }).update(data);
}

module.exports = { listAll, findById, create, listByProfesor, update };
