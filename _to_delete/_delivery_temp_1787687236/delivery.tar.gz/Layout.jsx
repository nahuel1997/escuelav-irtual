import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import ChatWidget from './ChatWidget';
import CartDrawer from './CartDrawer';
import { useContent } from '../hooks/useContent';
import { useFonts } from '../hooks/useFonts';
import { useTheme } from '../hooks/useTheme';
import { useFavicon } from '../hooks/useFavicon';

export default function Layout() {
  // Se piden acá arriba para poder aplicar tipografía, colores de marca y
  // favicon elegidos en Generales a todo el sitio público apenas carga
  // cualquier página.
  const { values } = useContent();
  useFonts(values);
  useTheme(values);
  useFavicon(values);

  return (
    <>
      <Navbar />
      <main>
        <Outlet />
      </main>
      <Footer />
      {/* Chat de contacto flotante — solo se muestra si hay un alumno o
          profesor logueado (ver adentro del componente); un visitante
          anónimo o un admin no lo ven. */}
      <ChatWidget />
      {/* Panel lateral del carrito — montado acá (una sola vez, fuera del
          <Outlet/>) para poder abrirse con el ícono del Navbar desde
          cualquier página sin perder el estado; solo se renderiza para
          alumnos (ver adentro del componente). */}
      <CartDrawer />
    </>
  );
}
