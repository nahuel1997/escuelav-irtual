// Contexto del carrito de compras. Solo tiene sentido para el sitio
// público (alumno/profesor comprando cursos), así que se monta junto a
// AuthProvider en main.jsx, no en el panel de admin. El carrito vive en la
// base de datos (ver backend/src/models/cart.model.js) — este contexto
// solo cachea en memoria lo que ya devolvió la API para no repetir el
// pedido en cada componente que necesita saber "cuántos ítems hay".
import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from './AuthContext';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  // Estado del panel lateral (CartDrawer.jsx), a propósito acá y no en un
  // useState local del componente: el ícono del carrito vive en el Navbar,
  // pero el panel se monta una sola vez en Layout.jsx para poder abrirse
  // desde cualquier página — necesitan compartir el mismo estado "abierto".
  const [drawerAbierto, setDrawerAbierto] = useState(false);
  const abrirDrawer = useCallback(() => setDrawerAbierto(true), []);
  const cerrarDrawer = useCallback(() => setDrawerAbierto(false), []);
  const toggleDrawer = useCallback(() => setDrawerAbierto((v) => !v), []);

  const refrescar = useCallback(async () => {
    if (!user) {
      setItems([]);
      return;
    }
    setLoading(true);
    try {
      const { items: nuevos } = await api.get('/cart', { tokenKey: 'token' });
      setItems(nuevos);
    } catch (_e) {
      // Best effort: si falla (ej: sesión vencida), simplemente no se
      // actualiza el carrito — no tiene sentido romper la navegación por
      // esto.
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    refrescar();
  }, [refrescar]);

  async function agregar(courseId) {
    const { items: nuevos } = await api.post('/cart/items', { course_id: courseId }, { tokenKey: 'token' });
    setItems(nuevos);
  }

  async function quitar(courseId) {
    const { items: nuevos } = await api.delete(`/cart/items/${courseId}`, { tokenKey: 'token' });
    setItems(nuevos);
  }

  async function checkout() {
    const resultado = await api.post('/cart/checkout', {}, { tokenKey: 'token' });
    setItems([]);
    return resultado;
  }

  return (
    <CartContext.Provider value={{
      items, loading, refrescar, agregar, quitar, checkout,
      drawerAbierto, abrirDrawer, cerrarDrawer, toggleDrawer,
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart debe usarse dentro de un <CartProvider>');
  return ctx;
}
