import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import { useContent } from '../hooks/useContent';
import { useFonts } from '../hooks/useFonts';
import { useTheme } from '../hooks/useTheme';
import { useFavicon } from '../hooks/useFavicon';

export default function Layout() {
  // Se piden acá arriba para poder aplicar tipografía, colores de marca y
  // favicon elegidos en Generales a todo el sitio público apenas carga
  // cualquier página.
  const { values } = useContent();
  useFonts(values);
  useTheme(values);
  useFavicon(values);

  return (
    <>
      <Navbar />
      <main>
        <Outlet />
      </main>
      <Footer />
    </>
  );
}
