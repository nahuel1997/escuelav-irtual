// Registro de todo el contenido editable del sitio desde
// /admin-panel/contenido. Está organizado por página (cada una es una
// sub-pestaña del panel) para que sea fácil ubicar qué se edita dónde.
//
// Tipos de campo:
//   texto     -> input o textarea (según `textarea: true`)
//   imagen    -> sube un archivo, guarda la URL
//   color     -> selector de color (#rrggbb)
//   seleccion -> lista fija de opciones (tipografías, ver options)
//   boton     -> referencia a una "Opción N" del registro de botones
//                (Generales). Si `soloColor` es true, esa opción solo
//                aporta color de fondo/texto: el link del botón queda fijo
//                en código porque el botón dispara una acción (enviar un
//                formulario, comprar) y no puede apuntar a otro lado.
//
// Para agregar un campo nuevo: sumarlo acá (en la página que corresponda)
// y leerlo con useContent() en la página pública correspondiente.
export const CONTENT_PAGES = [
  {
    id: 'general',
    label: 'Generales',
    campos: [
      { clave: 'general.logo', tipo: 'imagen', label: 'Logo del sitio' },
      { clave: 'general.logo.alt', tipo: 'texto', label: 'Texto alternativo del logo (SEO/accesibilidad)', default: 'Escuela Online' },
      { clave: 'general.favicon', tipo: 'imagen', label: 'Favicon (ícono de la pestaña del navegador — PNG o SVG cuadrado)' },
      { clave: 'general.tipografia.titulos', tipo: 'seleccion', opciones: 'titulos', label: 'Tipografía de títulos', default: 'syne' },
      { clave: 'general.tipografia.texto', tipo: 'seleccion', opciones: 'texto', label: 'Tipografía de texto', default: 'inter' },
      { clave: 'general.color_primario', tipo: 'color', label: 'Color primario (botones y títulos por defecto en todo el sitio)', default: '#1c3d5a' },
      { clave: 'general.color_acento', tipo: 'color', label: 'Color de acento (links y detalles sobre fondo oscuro)', default: '#e0972d' },
      { clave: 'general.color_fondo_oscuro', tipo: 'color', label: 'Color de fondo oscuro (footer y secciones de cierre en todo el sitio)', default: '#0f1b2a' },
      { clave: 'general.color_texto_oscuro', tipo: 'color', label: 'Color de texto sobre fondo oscuro', default: '#e7ecf2' },
      { clave: 'general.seo.sufijo', tipo: 'texto', label: 'Sufijo del título (aparece en la pestaña del navegador)', default: 'Escuela Online' },
      { clave: 'general.seo.descripcion_default', tipo: 'texto', textarea: true, label: 'Meta descripción por defecto (SEO)', default: 'Plataforma de cursos online con classroom, tareas, logros y creador de CV.' },
    ],
  },
  {
    id: 'home',
    label: 'Home',
    campos: [
      { clave: 'home.hero.badge', tipo: 'texto', label: 'Etiqueta (badge)', default: 'Educación online' },
      { clave: 'home.hero.titulo', tipo: 'texto', label: 'Título principal', default: 'Aprendé a tu ritmo, con seguimiento real de tus profesores' },
      { clave: 'home.hero.subtitulo', tipo: 'texto', textarea: true, label: 'Subtítulo', default: 'Cursos, classroom con entrega de tareas, logros y un creador de CV que arma tu currículum con lo que vas aprendiendo en la plataforma.' },
      { clave: 'home.hero.imagen', tipo: 'imagen', label: 'Imagen de portada' },
      { clave: 'home.hero.color_fondo', tipo: 'color', label: 'Color de fondo de la portada', default: '#ffffff' },
      { clave: 'home.hero.boton_principal', tipo: 'boton', label: 'Botón "Ver cursos disponibles"', default: '' },
      { clave: 'home.hero.boton_secundario', tipo: 'boton', label: 'Botón "Crear cuenta gratis"', default: '' },
      { clave: 'home.cta.boton', tipo: 'boton', label: 'Botón final "Registrarme" (sección oscura de cierre)', default: '' },
      { clave: 'home.seo.titulo', tipo: 'texto', label: 'Título SEO de esta página', default: 'Inicio' },
      { clave: 'home.seo.descripcion', tipo: 'texto', textarea: true, label: 'Meta descripción de esta página' },
    ],
  },
  {
    id: 'contacto',
    label: 'Contacto',
    campos: [
      { clave: 'contacto.email', tipo: 'texto', label: 'Email de contacto', default: 'contacto@escuelaonline.demo' },
      { clave: 'contacto.telefono', tipo: 'texto', label: 'Teléfono / WhatsApp', default: '+54 11 5555 0000' },
      { clave: 'contacto.ubicacion', tipo: 'texto', label: 'Ubicación', default: 'Buenos Aires, Argentina' },
      { clave: 'contacto.color_fondo', tipo: 'color', label: 'Color de fondo de la página', default: '#0f1b2a' },
      { clave: 'contacto.boton_enviar', tipo: 'boton', label: 'Botón "Enviar mensaje" (solo color, es un envío de formulario)', default: '', soloColor: true },
      { clave: 'contacto.seo.titulo', tipo: 'texto', label: 'Título SEO de esta página', default: 'Contacto' },
      { clave: 'contacto.seo.descripcion', tipo: 'texto', textarea: true, label: 'Meta descripción de esta página' },
    ],
  },
  {
    id: 'tienda',
    label: 'Tienda de cursos',
    campos: [
      { clave: 'tienda.titulo', tipo: 'texto', label: 'Título de la página', default: 'Tienda de cursos' },
      { clave: 'tienda.subtitulo', tipo: 'texto', label: 'Subtítulo', default: 'Elegí el curso que quieras empezar hoy.' },
      { clave: 'tienda.color_fondo', tipo: 'color', label: 'Color de fondo', default: '#ffffff' },
      { clave: 'tienda.seo.titulo', tipo: 'texto', label: 'Título SEO de esta página', default: 'Tienda de cursos' },
      { clave: 'tienda.seo.descripcion', tipo: 'texto', textarea: true, label: 'Meta descripción de esta página' },
    ],
  },
  {
    id: 'curso',
    label: 'Detalle de curso',
    campos: [
      { clave: 'curso.color_acento', tipo: 'color', label: 'Color del precio / acentos', default: '#1c3d5a' },
      { clave: 'curso.boton_comprar', tipo: 'boton', label: 'Botón "Comprar / Inscribirme" (solo color, dispara la compra)', default: '', soloColor: true },
      { clave: 'curso.seo.titulo', tipo: 'texto', label: 'Título SEO de esta página', default: 'Curso' },
      { clave: 'curso.seo.descripcion', tipo: 'texto', textarea: true, label: 'Meta descripción de esta página' },
    ],
  },
  {
    id: 'terminos',
    label: 'Términos y condiciones',
    campos: [
      { clave: 'terminos.seo.titulo', tipo: 'texto', label: 'Título SEO de esta página', default: 'Términos y condiciones' },
      { clave: 'terminos.seo.descripcion', tipo: 'texto', textarea: true, label: 'Meta descripción de esta página' },
    ],
  },
  {
    id: 'login',
    label: 'Ingresar',
    campos: [
      { clave: 'login.boton_ingresar', tipo: 'boton', label: 'Botón "Ingresar" (solo color, dispara el login)', default: '', soloColor: true },
      { clave: 'login.seo.titulo', tipo: 'texto', label: 'Título SEO de esta página', default: 'Ingresar' },
    ],
  },
  {
    id: 'registro',
    label: 'Crear cuenta',
    campos: [
      { clave: 'registro.boton_crear', tipo: 'boton', label: 'Botón "Crear cuenta" (solo color, dispara el registro)', default: '', soloColor: true },
      { clave: 'registro.seo.titulo', tipo: 'texto', label: 'Título SEO de esta página', default: 'Crear cuenta' },
    ],
  },
];

// Todos los campos "aplanados", útil para valores por defecto y para
// buscar un campo puntual por clave sin recorrer las páginas a mano.
export const CONTENT_FIELDS = CONTENT_PAGES.flatMap((p) => p.campos);

export function defaultsMap() {
  const m = {};
  CONTENT_FIELDS.forEach((f) => { m[f.clave] = f.default ?? ''; });
  return m;
}
