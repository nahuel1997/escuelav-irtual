// Estas 4 líneas tienen que ir antes de cualquier require de la app: fuerzan
// que se use una base sqlite descartable para tests, separada de la de
// desarrollo (data/escuela.sqlite3).
process.env.NODE_ENV = 'test';
process.env.DB_CLIENT = 'sqlite';
process.env.SQLITE_FILE = './data/test-auth.sqlite3';
process.env.JWT_SECRET = 'test-secret';

const fs = require('fs');
const path = require('path');
const request = require('supertest');

const dbFile = path.join(__dirname, '..', 'data', 'test-auth.sqlite3');

describe('Autenticación', () => {
  let app;
  let db;

  beforeAll(async () => {
    if (fs.existsSync(dbFile)) fs.unlinkSync(dbFile);
    db = require('../src/config/db');
    await db.migrate.latest();
    app = require('../src/app');
  });

  afterAll(async () => {
    await db.destroy();
    if (fs.existsSync(dbFile)) fs.unlinkSync(dbFile);
  });

  test('registra un usuario nuevo y devuelve token', async () => {
    const res = await request(app).post('/api/auth/register').send({
      nombre: 'Test',
      apellido: 'User',
      email: 'test1@escuela.demo',
      password: '123456',
    });
    expect(res.status).toBe(201);
    expect(res.body.token).toBeDefined();
    expect(res.body.user.email).toBe('test1@escuela.demo');
    expect(res.body.user.password_hash).toBeUndefined();
  });

  test('rechaza un registro con email duplicado', async () => {
    await request(app).post('/api/auth/register').send({
      nombre: 'Dup', apellido: 'Uno', email: 'dup@escuela.demo', password: '123456',
    });
    const res = await request(app).post('/api/auth/register').send({
      nombre: 'Dup', apellido: 'Dos', email: 'dup@escuela.demo', password: '123456',
    });
    expect(res.status).toBe(409);
  });

  test('login con credenciales correctas devuelve token', async () => {
    await request(app).post('/api/auth/register').send({
      nombre: 'Login', apellido: 'Test', email: 'login@escuela.demo', password: 'secreta123',
    });
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'login@escuela.demo', password: 'secreta123' });
    expect(res.status).toBe(200);
    expect(res.body.token).toBeDefined();
  });

  test('login con password incorrecta devuelve 401 con mensaje claro', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'login@escuela.demo', password: 'incorrecta' });
    expect(res.status).toBe(401);
    expect(res.body.error).toMatch(/contraseña/i);
  });

  test('login con un email que no existe devuelve 404 sugiriendo registrarse', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'no-existe@escuela.demo', password: 'cualquiera' });
    expect(res.status).toBe(404);
    expect(res.body.error).toMatch(/registr/i);
  });

  test('registro con email ya usado sugiere iniciar sesión en vez de solo decir "duplicado"', async () => {
    await request(app).post('/api/auth/register').send({
      nombre: 'Dup2', apellido: 'Uno', email: 'dup2@escuela.demo', password: '123456',
    });
    const res = await request(app).post('/api/auth/register').send({
      nombre: 'Dup2', apellido: 'Dos', email: 'dup2@escuela.demo', password: '123456',
    });
    expect(res.status).toBe(409);
    expect(res.body.error).toMatch(/iniciar sesión/i);
  });

  test('/api/auth/me sin token devuelve 401', async () => {
    const res = await request(app).get('/api/auth/me');
    expect(res.status).toBe(401);
  });

  test('/api/auth/me con token válido devuelve el usuario', async () => {
    const registro = await request(app).post('/api/auth/register').send({
      nombre: 'Me', apellido: 'Test', email: 'me@escuela.demo', password: '123456',
    });
    const res = await request(app).get('/api/auth/me').set('Authorization', `Bearer ${registro.body.token}`);
    expect(res.status).toBe(200);
    expect(res.body.user.email).toBe('me@escuela.demo');
  });
});
