const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const env = require('../config/env');
const userModel = require('../models/user.model');
const loginLogModel = require('../models/loginLog.model');
const { asyncHandler, AppError } = require('../middlewares/error.middleware');

function signToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, rol: user.rol, nombre: user.nombre },
    env.JWT_SECRET,
    { expiresIn: env.JWT_EXPIRES_IN }
  );
}

const register = asyncHandler(async (req, res) => {
  const { nombre, apellido, email, password } = req.body;

  if (!nombre || !apellido || !email || !password) {
    throw new AppError('Completá tu nombre, apellido, email y contraseña para crear la cuenta', 400);
  }
  if (password.length < 6) {
    throw new AppError('La contraseña tiene que tener al menos 6 caracteres', 400);
  }
  // El registro público SIEMPRE crea una cuenta de alumno. Las cuentas de
  // profesor y admin se crean únicamente desde el panel de administración
  // (POST /api/admin/users, protegido por rol admin) — ignoramos a
  // propósito cualquier "rol" que venga en el body para que nadie pueda
  // auto-asignarse profesor/admin mandando el campo a mano.
  const rolFinal = 'alumno';

  const existente = await userModel.findByEmail(email.toLowerCase().trim());
  if (existente) {
    throw new AppError('Ya existe una cuenta con ese email. Probá iniciar sesión en vez de registrarte.', 409);
  }

  const password_hash = await bcrypt.hash(password, 10);
  const user = await userModel.create({
    nombre: nombre.trim(),
    apellido: apellido.trim(),
    email: email.toLowerCase().trim(),
    password_hash,
    rol: rolFinal,
  });

  const token = signToken(user);
  // El registro de logins es un "nice to have" para el admin, no algo que
  // tenga que poder bloquear que alguien se registre/loguee — si falla
  // (ej: falta correr una migración nueva), lo logueamos server-side y
  // seguimos. Ver mismo criterio en errorLog.model.
  await loginLogModel.create(user.id).catch((e) => console.error('[login_logs]', e.message));
  res.status(201).json({ token, user });
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    throw new AppError('Ingresá tu email y tu contraseña', 400);
  }

  const user = await userModel.findByEmail(email.toLowerCase().trim());
  if (!user) {
    // Distinguimos "no existe cuenta" de "contraseña incorrecta" a
    // propósito, para poder guiar al usuario a registrarse en vez de
    // dejarlo adivinando. Trade-off de seguridad conocido: esto permite
    // enumerar qué emails están registrados. Para esta plataforma (una
    // escuela, no un sistema con datos sensibles) priorizamos la
    // claridad del mensaje; si en algún momento hace falta más
    // hermetismo, se vuelve a unificar en un solo mensaje genérico acá.
    throw new AppError('No encontramos ninguna cuenta con ese email. ¿Ya te registraste?', 404);
  }

  const passwordOk = await bcrypt.compare(password, user.password_hash);
  if (!passwordOk) {
    throw new AppError('La contraseña es incorrecta. Probá de nuevo.', 401);
  }

  const token = signToken(user);
  await loginLogModel.create(user.id).catch((e) => console.error('[login_logs]', e.message));
  const { password_hash, ...userPublico } = user;
  res.json({ token, user: userPublico });
});

const me = asyncHandler(async (req, res) => {
  const user = await userModel.findPublicById(req.user.id);
  if (!user) throw new AppError('Usuario no encontrado', 404);
  res.json({ user });
});

// Con JWT no hay sesión server-side para "cerrar": lo que hacemos acá es
// marcar en login_logs cuándo terminó esta conexión, para que el registro
// de logins del admin pueda mostrar inicio y fin. El frontend llama a este
// endpoint antes de descartar el token (ver AuthContext.logout()).
const logout = asyncHandler(async (req, res) => {
  await loginLogModel.closeOpenSession(req.user.id).catch((e) => console.error('[login_logs]', e.message));
  res.json({ ok: true });
});

module.exports = { register, login, me, logout };
