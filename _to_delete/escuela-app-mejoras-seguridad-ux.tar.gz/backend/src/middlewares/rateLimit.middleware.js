// Rate limiting para los dos endpoints de auth expuestos sin login
// (login y registro). No protege contra un atacante distribuido en muchas
// IPs distintas, pero frena el caso común — intentos repetidos desde un
// mismo script/IP — que era la ausencia de seguridad más concreta que
// tenía la API: nada frenaba a alguien probando contraseñas contra
// /api/auth/login en loop.
//
// Ventanas distintas a propósito: login se prueba muchas veces en uso
// normal (usuario que se equivoca de contraseña un par de veces), registro
// casi nunca más de una vez por persona real — así que el límite de
// registro puede ser más chico en relación a lo esperable sin molestar a
// nadie legítimo.
const rateLimit = require('express-rate-limit');

// Los tests (backend/tests/) hacen muchos logins seguidos contra la misma
// IP de loopback: sin este escape, la propia suite de tests terminaría
// bloqueada por su propio rate limit.
const skipEnTests = () => process.env.NODE_ENV === 'test';

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 10, // 10 intentos por IP en la ventana
  standardHeaders: true,
  legacyHeaders: false,
  skip: skipEnTests,
  message: { error: 'Demasiados intentos de inicio de sesión desde esta conexión. Esperá unos minutos y volvé a intentar.' },
});

const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hora
  max: 20, // 20 cuentas nuevas por IP por hora
  standardHeaders: true,
  legacyHeaders: false,
  skip: skipEnTests,
  message: { error: 'Demasiadas cuentas creadas desde esta conexión. Probá de nuevo más tarde.' },
});

module.exports = { loginLimiter, registerLimiter };
