// Carga y valida las variables de entorno.
// Centralizar esto en un solo módulo evita leer `process.env.X` suelto por
// todo el código y permite fallar rápido si falta algo crítico.
require('dotenv').config();

const env = {
  PORT: process.env.PORT || 3000,
  NODE_ENV: process.env.NODE_ENV || 'development',
  DB_CLIENT: process.env.DB_CLIENT || 'sqlite',
  SQLITE_FILE: process.env.SQLITE_FILE || './data/escuela.sqlite3',
  DATABASE_URL: process.env.DATABASE_URL,
  JWT_SECRET: process.env.JWT_SECRET || 'dev-secret-inseguro-cambiar',
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
  FRONTEND_URL: process.env.FRONTEND_URL || 'http://localhost:3500',
};

if (env.NODE_ENV === 'production' && env.JWT_SECRET === 'dev-secret-inseguro-cambiar') {
  // Antes esto era solo un warning para no "romper un despliegue a último
  // momento" — pero un secreto de JWT conocido públicamente (está en este
  // mismo repo) en producción significa que cualquiera puede firmar tokens
  // válidos como cualquier usuario, incluido admin. Eso no es un problema
  // que se pueda dejar "para después": directamente no arrancamos.
  console.error('[FATAL] JWT_SECRET no fue configurado en producción (quedó el valor por defecto del repo).');
  console.error('Definilo en backend/.env antes de arrancar — con el secreto por defecto cualquiera puede falsificar sesiones, incluida la de admin.');
  process.exit(1);
}

module.exports = env;
