import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import PrivateRoute from './components/PrivateRoute';
import AdminRoute from './components/AdminRoute';
import AdminLayout from './components/AdminLayout';
import SupportRoute from './components/SupportRoute';
import SupportLayout from './components/SupportLayout';

import Home from './pages/Home';
import Contact from './pages/Contact';
import Login from './pages/Login';
import Register from './pages/Register';
import Store from './pages/Store';
import CourseDetail from './pages/CourseDetail';
import Cart from './pages/Cart';
import Terms from './pages/Terms';
import UserHome from './pages/UserHome';
import Profile from './pages/Profile';
import MyCourses from './pages/MyCourses';
import Achievements from './pages/Achievements';
import Classroom from './pages/Classroom';
import CourseUnitDetail from './pages/CourseUnitDetail';
import CourseChapter from './pages/CourseChapter';
import CvBuilder from './pages/CvBuilder';
import Calendar from './pages/Calendar';
import VerifyEmail from './pages/VerifyEmail';
import NotFound from './pages/NotFound';

import AdminLogin from './pages/admin/AdminLogin';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminTeachers from './pages/admin/AdminTeachers';
import AdminCourses from './pages/admin/AdminCourses';
import AdminContent from './pages/admin/AdminContent';
import AdminCalendar from './pages/admin/AdminCalendar';
import AdminErrors from './pages/admin/AdminErrors';
import AdminLogins from './pages/admin/AdminLogins';
import AdminTesting from './pages/admin/AdminTesting';
import AdminMails from './pages/admin/AdminMails';
import AdminSupportAgents from './pages/admin/AdminSupportAgents';
import AdminChats from './pages/admin/AdminChats';

import SupportLogin from './pages/support/SupportLogin';
import SupportInbox from './pages/support/SupportInbox';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        {/* Públicas */}
        <Route path="/" element={<Home />} />
        <Route path="/contacto" element={<Contact />} />
        <Route path="/tienda" element={<Store />} />
        <Route path="/tienda/:id" element={<CourseDetail />} />
        <Route path="/terminos" element={<Terms />} />
        <Route path="/ingresar" element={<Login />} />
        <Route path="/registrarme" element={<Register />} />

        {/* Privadas: cualquier usuario logueado */}
        <Route element={<PrivateRoute />}>
          <Route path="/panel" element={<UserHome />} />
          <Route path="/perfil" element={<Profile />} />
          <Route path="/mis-cursos" element={<MyCourses />} />
          <Route path="/classroom/:courseId" element={<Classroom />} />
          <Route path="/classroom/:courseId/unidades/:unitId" element={<CourseUnitDetail />} />
          <Route path="/classroom/:courseId/unidades/:unitId/capitulos/:chapterId" element={<CourseChapter />} />
          <Route path="/cv" element={<CvBuilder />} />
          <Route path="/verificar-email" element={<VerifyEmail />} />
        </Route>

        {/* Privadas: solo alumnos (carrito, logros y cv son conceptos de alumno) */}
        <Route element={<PrivateRoute roles={['alumno']} />}>
          <Route path="/logros" element={<Achievements />} />
          <Route path="/carrito" element={<Cart />} />
        </Route>

        {/* Privadas: alumno y profesor (no admin, que tiene su propia vista
            de calendario dentro del panel de administración) */}
        <Route element={<PrivateRoute roles={['alumno', 'profesor']} />}>
          <Route path="/calendario" element={<Calendar />} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Route>

      {/* Panel de administración: área aparte, con su propio login y layout. */}
      <Route path="/admin-panel/ingresar" element={<AdminLogin />} />
      <Route element={<AdminRoute />}>
        <Route element={<AdminLayout />}>
          <Route path="/admin-panel" element={<AdminDashboard />} />
          <Route path="/admin-panel/profesores" element={<AdminTeachers />} />
          <Route path="/admin-panel/cursos" element={<AdminCourses />} />
          <Route path="/admin-panel/contenido" element={<AdminContent />} />
          <Route path="/admin-panel/calendario" element={<AdminCalendar />} />
          <Route path="/admin-panel/mails" element={<AdminMails />} />
          <Route path="/admin-panel/soporte" element={<AdminSupportAgents />} />
          <Route path="/admin-panel/chats" element={<AdminChats />} />
          <Route path="/admin-panel/errores" element={<AdminErrors />} />
          <Route path="/admin-panel/logins" element={<AdminLogins />} />
          <Route path="/admin-panel/testing" element={<AdminTesting />} />
        </Route>
      </Route>

      {/* Panel de soporte: otra área aparte, con su propio login (chat en
          vivo con alumnos/profesores — ver ChatWidget.jsx del lado público). */}
      <Route path="/soporte/ingresar" element={<SupportLogin />} />
      <Route element={<SupportRoute />}>
        <Route element={<SupportLayout />}>
          <Route path="/soporte" element={<SupportInbox />} />
        </Route>
      </Route>
    </Routes>
  );
}
