const bcrypt = require('bcryptjs');
const adminModel = require('../models/admin.model');
const userModel = require('../models/user.model');
const courseModel = require('../models/course.model');
const contentModel = require('../models/content.model');
const calendarModel = require('../models/calendarEvent.model');
const { esRolValido } = require('../utils/roles');
const { asyncHandler, AppError } = require('../middlewares/error.middleware');

const getDashboard = asyncHandler(async (req, res) => {
  const data = await adminModel.dashboard();
  res.json(data);
});

// --- Usuarios (crear profesores/admins — no hay registro público para esto) ---

const listUsersByRole = asyncHandler(async (req, res) => {
  const rol = req.query.rol || 'profesor';
  if (!esRolValido(rol)) throw new AppError('Rol inválido', 400);
  const users = await userModel.listByRole(rol);
  res.json({ users });
});

const createUser = asyncHandler(async (req, res) => {
  const { nombre, apellido, email, password, rol } = req.body;
  if (!nombre || !apellido || !email || !password || !rol) {
    throw new AppError('Faltan campos obligatorios (nombre, apellido, email, password, rol)', 400);
  }
  if (!esRolValido(rol)) throw new AppError('Rol inválido', 400);
  if (password.length < 6) throw new AppError('La contraseña debe tener al menos 6 caracteres', 400);

  const existente = await userModel.findByEmail(email.toLowerCase().trim());
  if (existente) throw new AppError('Ya existe una cuenta con ese email', 409);

  const password_hash = await bcrypt.hash(password, 10);
  const user = await userModel.create({
    nombre: nombre.trim(),
    apellido: apellido.trim(),
    email: email.toLowerCase().trim(),
    password_hash,
    rol,
  });
  res.status(201).json({ user });
});

// --- Cursos (el admin puede crear/editar cualquiera, asignando profesor) ---

const listCourses = asyncHandler(async (req, res) => {
  const courses = await courseModel.listAll();
  res.json({ courses });
});

const createCourse = asyncHandler(async (req, res) => {
  const { titulo, descripcion, precio, categoria, imagen_url, profesor_id } = req.body;
  if (!titulo || !descripcion) throw new AppError('Faltan título y/o descripción del curso', 400);
  if (!profesor_id) throw new AppError('Falta asignar un profesor al curso', 400);

  const profesor = await userModel.findById(profesor_id);
  if (!profesor || profesor.rol !== 'profesor') {
    throw new AppError('El profesor seleccionado no existe o no tiene rol de profesor', 400);
  }

  const [id] = await courseModel.create({
    titulo,
    descripcion,
    precio: precio || 0,
    categoria,
    imagen_url,
    profesor_id,
  });
  const course = await courseModel.findById(id);
  res.status(201).json({ course });
});

const updateCourse = asyncHandler(async (req, res) => {
  const course = await courseModel.findById(req.params.id);
  if (!course) throw new AppError('Curso no encontrado', 404);

  const { titulo, descripcion, precio, categoria, imagen_url, profesor_id } = req.body;
  const patch = {};
  if (titulo !== undefined) patch.titulo = titulo;
  if (descripcion !== undefined) patch.descripcion = descripcion;
  if (precio !== undefined) patch.precio = precio;
  if (categoria !== undefined) patch.categoria = categoria;
  if (imagen_url !== undefined) patch.imagen_url = imagen_url;

  if (profesor_id !== undefined) {
    const profesor = await userModel.findById(profesor_id);
    if (!profesor || profesor.rol !== 'profesor') {
      throw new AppError('El profesor seleccionado no existe o no tiene rol de profesor', 400);
    }
    patch.profesor_id = profesor_id;
  }

  await courseModel.update(req.params.id, patch);
  const actualizado = await courseModel.findById(req.params.id);
  res.json({ course: actualizado });
});

// --- Contenido del sitio (textos e imágenes editables) ---

const listContent = asyncHandler(async (req, res) => {
  const content = await contentModel.listAll();
  res.json({ content });
});

const updateContent = asyncHandler(async (req, res) => {
  const { clave } = req.params;
  const { tipo, valor } = req.body;
  if (valor === undefined) throw new AppError('Falta el valor', 400);
  const actualizado = await contentModel.upsert(clave, { tipo, valor });
  res.json({ content: actualizado });
});

// --- Subida de imágenes (portadas de curso y contenido del sitio) ---

const uploadImage = asyncHandler(async (req, res) => {
  if (!req.file) throw new AppError('Falta el archivo de imagen', 400);
  const url = `/uploads/imagenes/${req.file.filename}`;
  res.status(201).json({ url });
});

// --- Calendario (registro de todos los turnos alumno-profesor) ---

const listCalendarEvents = asyncHandler(async (req, res) => {
  const { estado } = req.query;
  const eventos = await calendarModel.listAll({ estado });
  res.json({ eventos });
});

module.exports = {
  getDashboard,
  listUsersByRole,
  createUser,
  listCourses,
  createCourse,
  updateCourse,
  listContent,
  updateContent,
  uploadImage,
  listCalendarEvents,
};
