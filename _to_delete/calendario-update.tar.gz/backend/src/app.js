// =============================================================================
// app.js — Punto de entrada de la API de la escuela.
// Alguien que nunca vio este proyecto debería poder entender el flujo
// completo leyendo solo este archivo y sus comentarios.
// =============================================================================

// 1) Variables de entorno: se cargan primero que nada (env.js hace el
//    require('dotenv').config() internamente) para que el resto de los
//    módulos ya las tengan disponibles al importarse.
const env = require('./config/env');

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');

const { notFoundHandler, errorHandler } = require('./middlewares/error.middleware');

// 2) Creación de la app de Express.
const app = express();

// 3) Middlewares globales (el orden importa):

// helmet agrega headers HTTP de seguridad por defecto (evita algunos
// ataques comunes: sniffing de MIME, clickjacking, etc.)
app.use(helmet({
  // Servimos PDFs generados (CV) y archivos subidos; relajamos la política
  // de recursos cruzados para que el frontend (otro puerto) pueda abrirlos.
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

// cors habilita que el frontend (React, corriendo en otro puerto/dominio)
// pueda llamar a esta API. Restringido a FRONTEND_URL por variable de entorno.
app.use(cors({ origin: env.FRONTEND_URL, credentials: true }));

// morgan loguea cada request entrante en consola (solo útil en desarrollo).
if (env.NODE_ENV !== 'test') {
  app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

// express.json() parsea bodies JSON entrantes (POST/PUT) a req.body.
app.use(express.json());

// Servimos los archivos subidos por los alumnos (entregas de tareas) y,
// eventualmente, imágenes de perfil. En producción esto normalmente se
// movería a un storage externo (S3, etc.), pero para arrancar alcanza con
// disco local.
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// 4) Montaje de rutas. Cada dominio de la app vive en su propio archivo de
//    rutas + controller, todas bajo el prefijo /api para separarlas
//    claramente de cualquier asset estático.
app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/users', require('./routes/users.routes'));
app.use('/api/courses', require('./routes/courses.routes'));
app.use('/api/classroom', require('./routes/classroom.routes'));
app.use('/api/calendar', require('./routes/calendar.routes'));
app.use('/api/admin', require('./routes/admin.routes'));
app.use('/api/content', require('./routes/content.routes'));
app.use('/api/achievements', require('./routes/achievements.routes'));
app.use('/api/contact', require('./routes/contact.routes'));
app.use('/api/cv', require('./routes/cv.routes'));

// Endpoint simple para chequear que el server está vivo (útil para health
// checks, monitoreo, o simplemente para probar que todo arrancó bien).
app.get('/api/health', (req, res) => {
  res.json({ ok: true, env: env.NODE_ENV, timestamp: new Date().toISOString() });
});

// 5) Manejo de errores centralizado: primero 404 para rutas que no
//    matchearon nada de arriba, después el handler genérico de errores.
app.use(notFoundHandler);
app.use(errorHandler);

// 6) Arranque del servidor. Solo lo levantamos si este archivo se ejecuta
//    directamente (no cuando lo importan los tests con supertest).
if (require.main === module) {
  app.listen(env.PORT, () => {
    console.log(`API de la escuela escuchando en http://localhost:${env.PORT}`);
    console.log(`CORS habilitado para: ${env.FRONTEND_URL}`);
  });
}

module.exports = app;
