const bcrypt = require('bcryptjs');

// Seed de datos de ejemplo para poder probar la app apenas se clona.
// Correr con: npm run seed
exports.seed = async function (knex) {
  // Limpiamos en orden inverso a las FK.
  await knex('site_content').del();
  await knex('calendar_events').del();
  await knex('user_achievements').del();
  await knex('submissions').del();
  await knex('assignments').del();
  await knex('enrollments').del();
  await knex('courses').del();
  await knex('achievements').del();
  await knex('users').del();

  const passwordHash = await bcrypt.hash('123456', 10);

  const [adminId] = await knex('users').insert({
    nombre: 'Admin',
    apellido: 'Escuela',
    email: 'admin@escuela.demo',
    password_hash: passwordHash,
    rol: 'admin',
  });

  const [profesorId] = await knex('users').insert({
    nombre: 'Laura',
    apellido: 'Gómez',
    email: 'profesora@escuela.demo',
    password_hash: passwordHash,
    rol: 'profesor',
  });

  const [alumnoId] = await knex('users').insert({
    nombre: 'Juan',
    apellido: 'Pérez',
    email: 'alumno@escuela.demo',
    password_hash: passwordHash,
    rol: 'alumno',
  });

  const cursos = await knex('courses')
    .insert([
      {
        titulo: 'Introducción a JavaScript',
        descripcion: 'Fundamentos del lenguaje: variables, funciones, DOM y buenas prácticas.',
        precio: 15000,
        categoria: 'Programación',
        imagen_url: '',
        profesor_id: profesorId,
      },
      {
        titulo: 'Backend con Node.js y Express',
        descripcion: 'Construí APIs REST, autenticación y conexión a bases de datos.',
        precio: 22000,
        categoria: 'Programación',
        imagen_url: '',
        profesor_id: profesorId,
      },
      {
        titulo: 'Diseño UX/UI para principiantes',
        descripcion: 'Principios de diseño centrado en el usuario y prototipado.',
        precio: 18000,
        categoria: 'Diseño',
        imagen_url: '',
        profesor_id: profesorId,
      },
    ])
    .returning('id');

  const primerCursoId = Array.isArray(cursos) && typeof cursos[0] === 'object' ? cursos[0].id : cursos[0];

  await knex('enrollments').insert({
    user_id: alumnoId,
    course_id: primerCursoId,
    payment_status: 'pagado',
    payment_method: 'simulado',
    transaction_id: 'SIM-DEMO-0001',
  });

  await knex('assignments').insert({
    course_id: primerCursoId,
    profesor_id: profesorId,
    titulo: 'Ejercicio: Calculadora simple',
    descripcion: 'Implementar una calculadora con las 4 operaciones básicas en JavaScript puro.',
    fecha_entrega: knex.fn.now(),
  });

  await knex('achievements').insert([
    { codigo: 'primer_curso', titulo: 'Primeros pasos', descripcion: 'Te inscribiste a tu primer curso', icono: '🚀' },
    { codigo: 'primera_entrega', titulo: 'Manos a la obra', descripcion: 'Entregaste tu primera tarea', icono: '📝' },
    { codigo: 'curso_completado', titulo: 'Curso completado', descripcion: 'Completaste un curso entero', icono: '🎓' },
  ]);

  // Un par de turnos de calendario de ejemplo: uno pendiente (para probar
  // el flujo de aceptar/rechazar) y uno ya aceptado (para ver cómo se
  // evita la superposición de horarios si se pide otro que se cruce).
  const mañana = new Date(Date.now() + 24 * 60 * 60 * 1000);
  const pasadoMañana = new Date(Date.now() + 48 * 60 * 60 * 1000);

  await knex('calendar_events').insert([
    {
      alumno_id: alumnoId,
      profesor_id: profesorId,
      course_id: primerCursoId,
      motivo: 'Dudas sobre el ejercicio de la calculadora',
      starts_at: new Date(mañana.setHours(15, 0, 0, 0)),
      ends_at: new Date(mañana.setHours(15, 30, 0, 0)),
      estado: 'pendiente',
    },
    {
      alumno_id: alumnoId,
      profesor_id: profesorId,
      course_id: primerCursoId,
      motivo: 'Repaso general antes del final',
      starts_at: new Date(pasadoMañana.setHours(10, 0, 0, 0)),
      ends_at: new Date(pasadoMañana.setHours(10, 45, 0, 0)),
      estado: 'aceptada',
    },
  ]);

  // Contenido inicial editable del sitio (el admin lo puede pisar desde
  // /admin-panel/contenido). Si una clave no está acá, el frontend usa su
  // propio valor por defecto.
  await knex('site_content').insert([
    { clave: 'home.hero.badge', tipo: 'texto', valor: 'Educación online' },
    { clave: 'home.hero.titulo', tipo: 'texto', valor: 'Aprendé a tu ritmo, con seguimiento real de tus profesores' },
    { clave: 'home.hero.subtitulo', tipo: 'texto', valor: 'Cursos, classroom con entrega de tareas, logros y un creador de CV que arma tu currículum con lo que vas aprendiendo en la plataforma.' },
    { clave: 'home.hero.imagen', tipo: 'imagen', valor: '' },
    { clave: 'contacto.email', tipo: 'texto', valor: 'contacto@escuelaonline.demo' },
    { clave: 'contacto.telefono', tipo: 'texto', valor: '+54 11 5555 0000' },
    { clave: 'contacto.ubicacion', tipo: 'texto', valor: 'Buenos Aires, Argentina' },
  ]);

  console.log('Seed cargado. Usuarios demo:');
  console.log('  admin:     admin@escuela.demo / 123456');
  console.log('  profesor:  profesora@escuela.demo / 123456');
  console.log('  alumno:    alumno@escuela.demo / 123456');
};
