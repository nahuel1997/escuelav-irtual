const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin.controller');
const { requireAuth, requireRole } = require('../middlewares/auth.middleware');
const { uploadImagen } = require('../middlewares/upload.middleware');

// Todo /api/admin/* requiere estar logueado Y tener rol admin.
router.use(requireAuth, requireRole('admin'));

router.get('/dashboard', adminController.getDashboard);

router.get('/users', adminController.listUsersByRole);
router.post('/users', adminController.createUser);

router.get('/courses', adminController.listCourses);
router.post('/courses', adminController.createCourse);
router.put('/courses/:id', adminController.updateCourse);

router.get('/content', adminController.listContent);
router.put('/content/:clave', adminController.updateContent);

router.post('/upload-imagen', uploadImagen, adminController.uploadImage);

router.get('/calendario', adminController.listCalendarEvents);

module.exports = router;
