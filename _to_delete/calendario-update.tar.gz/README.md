# Escuela Online

Plataforma tipo escuela/LMS: sitio público (home + contacto), login de
usuarios, panel de alumno/profesor, tienda de cursos, classroom (tareas y
entregas), calendario de turnos alumno-profesor, logros, términos y
condiciones, y un creador de CV en PDF.

Monorepo con dos proyectos independientes:

```
escuela-app/
├─ backend/     API REST (Node.js + Express)
└─ frontend/    SPA (React + Vite)
```

## Stack

- **Backend:** Node.js + Express, [knex](https://knexjs.org/) como query
  builder (con migraciones versionadas), JWT para sesión, bcrypt para
  contraseñas, multer para subida de archivos, pdfkit para el CV.
- **Base de datos:** arranca en **SQLite** (cero instalación, un archivo en
  `backend/data/`). Está armada para migrar a **PostgreSQL** solo cambiando
  variables de entorno — ver más abajo.
- **Frontend:** React (Vite) + React Router, sin librería de UI externa
  (CSS propio, tipografías Syne/Inter).
- **Pagos:** la compra de cursos está **simulada** (no se cobra nada real
  todavía). Aislada en `backend/src/services/payments.service.js` para
  poder conectar Mercado Pago (o la pasarela que sea) el día de mañana
  tocando un solo archivo.

## Instalación

Abrí PowerShell en `escuela-app/backend` y `escuela-app/frontend` (dos
terminales, una por proyecto) y corré:

```powershell
# --- Backend ---
cd "C:\Users\Dba24\Desktop\escuela-app\backend"
npm install
Copy-Item .env.example .env
npm run migrate
npm run seed
npm run dev
```

```powershell
# --- Frontend (en otra terminal) ---
cd "C:\Users\Dba24\Desktop\escuela-app\frontend"
npm install
Copy-Item .env.example .env
npm run dev
```

- Backend disponible en `http://localhost:3000`
- Frontend disponible en `http://localhost:3500`

### Usuarios de prueba (cargados por `npm run seed`)

| Rol       | Email                    | Contraseña |
|-----------|--------------------------|------------|
| Admin     | admin@escuela.demo       | 123456     |
| Profesor  | profesora@escuela.demo   | 123456     |
| Alumno    | alumno@escuela.demo      | 123456     |

El registro público (`/registrarme`) solo crea cuentas de **alumno**. Las
cuentas de profesor y de admin las crea un administrador desde
`/admin-panel/profesores` (o, para el primer admin, se cargan por seed /
directo en la base — no hay registro público para ese rol).

## Variables de entorno

**backend/.env** (ver `backend/.env.example`):

```
PORT=3000
NODE_ENV=development
DB_CLIENT=sqlite            # sqlite | postgres
SQLITE_FILE=./data/escuela.sqlite3
DATABASE_URL=postgresql://usuario:password@localhost:5432/escuela_db
JWT_SECRET=cambiar-este-secreto-en-produccion
JWT_EXPIRES_IN=7d
FRONTEND_URL=http://localhost:3500
```

**frontend/.env** (ver `frontend/.env.example`):

```
VITE_API_URL=http://localhost:3000/api
```

### Migrar de SQLite a PostgreSQL

1. Instalar Postgres (local o Docker) y crear la base:
   ```powershell
   docker run --name pg-escuela -e POSTGRES_PASSWORD=postgres -e POSTGRES_DB=escuela_db -p 5432:5432 -d postgres
   ```
2. En `backend/.env`, cambiar `DB_CLIENT=postgres` y completar
   `DATABASE_URL`.
3. Instalar el driver de Postgres: `npm install pg`.
4. Correr `npm run migrate` y `npm run seed` de nuevo. El resto del código
   (controllers, models) no necesita ningún cambio: todos hablan con knex,
   no con el driver de la base directamente.

## Estructura del backend

```
backend/src/
├─ app.js                  # punto de entrada, súper comentado
├─ config/                 # env.js, db.js
├─ db/                     # knexfile.js, migrations/, seeds/
├─ controllers/            # lógica de cada endpoint
├─ routes/                 # definición de rutas por dominio
├─ middlewares/             # auth (JWT + roles), errores, upload (multer)
├─ models/                 # acceso a datos (una capa fina sobre knex)
└─ services/                # payments.service.js, cv.service.js
```

## Funcionalidades y endpoints principales

| Área          | Endpoints                                                      |
|---------------|------------------------------------------------------------------|
| Auth          | `POST /api/auth/register`, `/login`, `GET /api/auth/me`         |
| Perfil        | `GET/PUT /api/users/profile`                                    |
| Tienda        | `GET /api/courses`, `GET /api/courses/:id`, `POST /api/courses` (profesor) |
| Inscripción   | `POST /api/courses/:id/enroll` (pago simulado), `GET /api/courses/mine` |
| Classroom     | `GET/POST /api/classroom/courses/:courseId/assignments`, `POST /api/classroom/assignments/:id/submissions` (archivo), `GET .../submissions`, `PUT /api/classroom/submissions/:id/grade` |
| Logros        | `GET /api/achievements`, `GET /api/achievements/mine`           |
| Contacto      | `POST /api/contact`                                              |
| Creador de CV | `POST /api/cv/generate` → devuelve un PDF                        |
| Completar curso | `GET /api/classroom/courses/:id/students`, `PUT .../students/:userId/complete` (profesor del curso o admin) |
| Contenido público | `GET /api/content` → textos/imágenes editables para Home/Contacto/Footer |
| Profesores (listado) | `GET /api/users/profesores` → cualquier usuario logueado, para elegir con quién pedir un turno |
| Calendario    | `GET /api/calendar/mis-turnos`, `POST /api/calendar/turnos` (alumno), `PUT /api/calendar/turnos/:id/aceptar` \| `/rechazar` \| `/cancelar` |
| **Admin**     | `GET /api/admin/dashboard`, `GET/POST /api/admin/users`, `GET/POST/PUT /api/admin/courses`, `GET/PUT /api/admin/content`, `POST /api/admin/upload-imagen`, `GET /api/admin/calendario` (todo protegido por rol admin) |

Roles: **alumno**, **profesor** y **admin**. Un profesor crea tareas,
revisa/califica entregas, marca cursadas como completadas y acepta/rechaza
turnos; un alumno se inscribe, entrega tareas, junta logros y pide turnos
con sus profesores; un admin gestiona todo desde el panel (ver abajo).

### Calendario de turnos (`/calendario`)

Página privada para alumno y profesor (no para admin, que tiene su propia
vista de solo lectura, ver más abajo):

- El **alumno** elige un profesor (y opcionalmente un curso propio), un
  motivo y un horario, y solicita el turno. Queda en estado `pendiente`.
- El **profesor** ve las solicitudes pendientes y las acepta o rechaza
  (con una nota opcional). También ve su agenda ya confirmada.
- Cualquiera de las dos partes puede **cancelar** un turno pendiente o ya
  aceptado.
- **Que no se sobrepongan** se garantiza a nivel de base de datos: no se
  puede solicitar (ni aceptar) un turno cuyo horario se cruza con otro
  turno ya `aceptado` del mismo profesor (`calendarEvent.model.js →
  hasOverlap`). El chequeo corre tanto al solicitar como al aceptar, para
  cubrir el caso de dos solicitudes pendientes que se superponen entre sí
  (el profesor solo puede confirmar una).

## Frontend — páginas

Públicas: Home, Contacto, Tienda de cursos, Detalle de curso, Términos y
condiciones, Login, Registro.

Privadas (requieren login): Panel (intro), Perfil, Mis cursos, Classroom
(vista distinta para alumno/profesor, incluye marcar cursada completada),
Calendario (turnos alumno-profesor, vista distinta según rol), Creador de
CV. Logros es privada y exclusiva de alumnos.

El menú de navegación y el panel/intro (`/panel`) también cambian según el
rol: alumno y profesor no ven las mismas opciones, porque cumplen
funciones distintas en la plataforma (ver `Navbar.jsx` y `UserHome.jsx`).

## Panel de administración (`/admin-panel`)

Área separada del sitio público, con su propio login (`/admin-panel/ingresar`)
y layout (sidebar), protegida por rol `admin`:

- **Dashboard** (`/admin-panel`): cursos vendidos, alumnos, cursos
  completados, tareas revisadas, y una tabla de profesores con cursos que
  dictan y tareas revisadas/pendientes.
- **Profesores** (`/admin-panel/profesores`): alta de cuentas de profesor
  (única forma de crearlas) y listado de las existentes.
- **Cursos** (`/admin-panel/cursos`): crear cursos nuevos (asignando
  profesor) y editar los existentes, con subida de imagen de portada.
- **Contenido del sitio** (`/admin-panel/contenido`): edita los textos e
  imagen de la portada de Home y los datos de contacto (usados tanto en la
  página de Contacto como en el footer). Los campos editables están
  centralizados en `frontend/src/config/content.js` — para hacer editable
  un texto/imagen nuevo, se agrega ahí y se lee con el hook `useContent()`
  en la página pública correspondiente. Hoy cubre la portada de Home y los
  datos de contacto; no es un editor de página completa.
- **Calendario** (`/admin-panel/calendario`): registro de **todos** los
  turnos solicitados en la plataforma (alumno, profesor, curso, horario,
  motivo y estado), con filtro por estado. Es de solo lectura — aceptar,
  rechazar o cancelar sigue siendo cosa del alumno y el profesor
  involucrados, no del admin.

## Tests

```powershell
cd "C:\Users\Dba24\Desktop\escuela-app\backend"
npm test
```

Cubre el flujo de registro/login, creación de curso → inscripción (compra
simulada) → logro otorgado automáticamente, el panel de admin (permisos,
alta de profesor, alta/edición de curso, edición de contenido, dashboard)
y el calendario de turnos (solicitar, aceptar, rechazar, cancelar,
permisos por rol/titularidad, y el chequeo de superposición de horarios).

## Decisiones y próximos pasos pendientes

- **Pagos reales:** hoy es 100% simulado. `payments.service.js` tiene
  comentado cómo se conectaría Mercado Pago.
- **Envío de emails:** el formulario de contacto guarda el mensaje en la
  base pero no envía email todavía (falta configurar SMTP).
- **Storage de archivos:** las entregas de tareas se guardan en disco local
  (`backend/uploads/`). Para producción conviene mover esto a un storage
  externo (S3 o similar).
- **Frontend/QA:** este README y el código cubren el backend y el frontend
  a nivel funcional; falta una revisión de diseño/UX más fina y testing
  end-to-end si se quiere llevar a producción.
