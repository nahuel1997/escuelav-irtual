import { NavLink, Outlet, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const links = [
  { to: '/admin-panel', label: 'Dashboard', end: true },
  { to: '/admin-panel/cursos', label: 'Cursos' },
  { to: '/admin-panel/profesores', label: 'Profesores' },
  { to: '/admin-panel/contenido', label: 'Contenido del sitio' },
  { to: '/admin-panel/calendario', label: 'Calendario' },
];

// Layout propio del backoffice: sidebar oscuro fijo + contenido a la
// derecha. Deliberadamente distinto del Navbar/Footer públicos para que
// se sienta como un área aparte (como el /pmt-admin de referencia).
export default function AdminLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate('/admin-panel/ingresar');
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <aside style={{ width: 220, background: 'var(--color-dark-bg)', color: '#fff', padding: '24px 16px', flexShrink: 0 }}>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: '1.1rem', marginBottom: 24 }}>
          Escuela Online<br /><span style={{ color: 'var(--color-accent)', fontSize: '0.85rem' }}>Panel de admin</span>
        </div>
        <nav style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              style={({ isActive }) => ({
                padding: '10px 12px',
                borderRadius: 8,
                color: isActive ? '#fff' : '#b7c2cf',
                background: isActive ? 'rgba(255,255,255,0.08)' : 'transparent',
                textDecoration: 'none',
                fontSize: '0.92rem',
              })}
            >
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div style={{ marginTop: 40, borderTop: '1px solid rgba(255,255,255,0.12)', paddingTop: 16 }}>
          <p style={{ color: '#b7c2cf', fontSize: '0.85rem', margin: 0 }}>{user?.nombre} {user?.apellido}</p>
          <Link to="/" style={{ fontSize: '0.8rem', color: '#8b97a5', display: 'block', marginTop: 8 }}>← Volver al sitio</Link>
          <button className="btn btn-outline btn-sm" style={{ marginTop: 10, borderColor: '#455568', color: '#fff' }} onClick={handleLogout}>
            Cerrar sesión
          </button>
        </div>
      </aside>

      <main style={{ flex: 1, background: 'var(--color-bg-alt)', padding: '32px 40px', overflowX: 'auto' }}>
        <Outlet />
      </main>
    </div>
  );
}
