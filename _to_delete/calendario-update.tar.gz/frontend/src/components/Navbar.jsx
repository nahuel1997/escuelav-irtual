import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// El menú de navegación depende del rol: alumno y profesor usan la
// plataforma para cosas distintas, así que no tiene sentido mostrarles las
// mismas opciones. Los links públicos (Inicio/Contacto) son para todos.
function getNavLinks(user) {
  const publicos = [
    { to: '/', label: 'Inicio', end: true },
    { to: '/contacto', label: 'Contacto' },
  ];

  if (!user) {
    return [...publicos, { to: '/tienda', label: 'Tienda de cursos' }];
  }

  if (user.rol === 'profesor') {
    return [
      ...publicos,
      { to: '/panel', label: 'Mi panel' },
      { to: '/mis-cursos', label: 'Mis cursos' },
      { to: '/calendario', label: 'Calendario' },
    ];
  }

  // alumno
  return [
    ...publicos,
    { to: '/tienda', label: 'Tienda de cursos' },
    { to: '/panel', label: 'Mi panel' },
    { to: '/mis-cursos', label: 'Mis cursos' },
    { to: '/calendario', label: 'Calendario' },
    { to: '/logros', label: 'Logros' },
    { to: '/cv', label: 'Creador de CV' },
  ];
}

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const links = getNavLinks(user);

  function handleLogout() {
    logout();
    navigate('/');
  }

  return (
    <header style={{ borderBottom: '1px solid var(--color-border)', background: '#fff', position: 'sticky', top: 0, zIndex: 20 }}>
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 68 }}>
        <Link to="/" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: '1.25rem', color: 'var(--color-primary-dark)' }}>
          Escuela Online
        </Link>

        <nav style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className="text-muted">
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {!user && (
            <>
              <Link to="/ingresar" className="btn btn-outline btn-sm">Ingresar</Link>
              <Link to="/registrarme" className="btn btn-primary btn-sm">Registrarme</Link>
            </>
          )}
          {user && (
            <>
              <Link to="/perfil" className="text-muted" style={{ fontSize: '0.9rem' }}>
                {user.nombre} <span className="badge">{user.rol}</span>
              </Link>
              <button className="btn btn-outline btn-sm" onClick={handleLogout}>Cerrar sesión</button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
