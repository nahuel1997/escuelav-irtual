# Escuela Online

Plataforma tipo escuela/LMS: sitio público (home + contacto), login de
usuarios con validación de cuenta por mail, panel de alumno/profesor,
tienda de cursos con carrito de compras, classroom (tareas y entregas, más
un temario por curso — unidades y capítulos en video con progreso,
comentarios y desbloqueo configurable), calendario de turnos
alumno-profesor con recordatorio automático, logros,
términos y condiciones, un creador de CV en PDF, un motor de mails
transaccionales y de campaña administrable desde el backoffice, y un chat
de soporte en vivo (WebSockets) con su propio panel de agentes.

Monorepo con dos proyectos independientes:

```
escuela-app/
├─ backend/     API REST (Node.js + Express)
└─ frontend/    SPA (React + Vite)
```

## Stack

- **Backend:** Node.js + Express, [knex](https://knexjs.org/) como query
  builder (con migraciones versionadas), JWT para sesión, bcrypt para
  contraseñas, multer para subida de archivos, pdfkit para el CV,
  [nodemailer](https://nodemailer.com/) para el envío de mails,
  [node-cron](https://www.npmjs.com/package/node-cron) para los jobs
  programados (carrito abandonado, inactividad, recordatorio de turno) y
  [Socket.io](https://socket.io/) para el chat de soporte en vivo.
- **Base de datos:** arranca en **SQLite** (cero instalación, un archivo en
  `backend/data/`). Está armada para migrar a **PostgreSQL** solo cambiando
  variables de entorno — ver más abajo.
- **Frontend:** React (Vite) + React Router, sin librería de UI externa
  (CSS propio, tipografías Syne/Inter).
- **Pagos:** la compra de cursos está **simulada** (no se cobra nada real
  todavía). Aislada en `backend/src/services/payments.service.js` para
  poder conectar Mercado Pago (o la pasarela que sea) el día de mañana
  tocando un solo archivo.
- **Mails:** motor propio aislado en `backend/src/services/mail.service.js`
  (mismo criterio que pagos/storage). Arranca en **modo prueba** (Ethereal:
  no manda nada a casillas reales, cada envío queda en el Registro del
  backoffice con un link para verlo) y pasa a un proveedor real con solo
  completar `SMTP_HOST` y compañía en `backend/.env` — ver más abajo.
- **Chat de soporte en vivo:** WebSockets con Socket.io, aislado en
  `backend/src/realtime/chatSocket.js` — es la única parte de la app que
  no es REST puro (todo lo demás se lee/escribe con fetch normal). Un
  widget flotante en el sitio público habla en tiempo real con un panel
  propio (`/soporte`) para agentes de soporte — ver más abajo.
- **Storage de archivos:** hoy en disco local (`backend/uploads/`), pero
  aislado en `backend/src/services/storage.service.js` con el mismo
  criterio que los pagos — migrar a S3 (o el que sea) el día de mañana es
  tocar ese archivo y nada más.
- **Seguridad:** helmet + CORS restringido a `FRONTEND_URL`, contraseñas
  con bcrypt, rate limiting en login/registro/validación de cuenta
  (`express-rate-limit`), el server no arranca en producción si quedó el
  `JWT_SECRET` por defecto, y el login no distingue "no existe la cuenta"
  de "contraseña incorrecta" (mismo mensaje genérico) para no permitir
  enumerar emails registrados.

## Instalación

Abrí PowerShell en `escuela-app/backend` y `escuela-app/frontend` (dos
terminales, una por proyecto) y corré:

```powershell
# --- Backend ---
cd "C:\Users\Dba24\Desktop\escuela-app\backend"
npm install
Copy-Item .env.example .env
npm run migrate
npm run seed
npm run dev
```

```powershell
# --- Frontend (en otra terminal) ---
cd "C:\Users\Dba24\Desktop\escuela-app\frontend"
npm install
Copy-Item .env.example .env
npm run dev
```

- Backend disponible en `http://localhost:3000`
- Frontend disponible en `http://localhost:3500`

> Si venís de una versión anterior del proyecto (ya tenías `node_modules`
> instalado), alcanza con `npm install` de nuevo en `backend` **y en
> `frontend`** (para sumar `nodemailer`/`node-cron`/`socket.io` de un lado
> y `socket.io-client` del otro) y `npm run migrate` en el backend para
> sumar las tablas nuevas (carrito, mails, chat) — **no corras `npm run
> seed` en una app que ya usaste**, ver la advertencia de abajo.

**⚠️ `npm run seed` es destructivo — pensado solo para la instalación
inicial, no para actualizar una app que ya tiene datos reales.** Borra
usuarios, cursos, turnos, logros y **todo** el contenido del sitio (los
colores, fuentes, logo y textos que hayas cargado desde
`/admin-panel/contenido`) y los reemplaza por los 3 usuarios demo y un
puñado de textos por defecto — sin aviso ni backup. El seed de plantillas
de mail (`002_email_templates.js`) tampoco es 100% seguro de re-correr: si
ya editaste una plantilla desde el backoffice, un `npm run seed` la vuelve
a la versión de fábrica. Desde esta versión, `001_demo_data.js` se cancela
solo si ya hay usuarios cargados (hace falta `FORCE_SEED=true` para
forzarlo) — pero **la única forma real de no perder nada es no correrlo**
salvo en una base vacía recién creada. Si necesitás las tablas nuevas de
una funcionalidad que se agregó después, alcanza con `npm run migrate`.

### Usuarios de prueba (cargados por `npm run seed`)

| Rol       | Email                    | Contraseña |
|-----------|--------------------------|------------|
| Admin     | admin@escuela.demo       | 123456     |
| Profesor  | profesora@escuela.demo   | 123456     |
| Alumno    | alumno@escuela.demo      | 123456     |

El registro público (`/registrarme`) solo crea cuentas de **alumno**. Las
cuentas de profesor, de admin y de soporte las crea un administrador desde
`/admin-panel/profesores` / `/admin-panel/soporte` (o, para el primer
admin, se cargan por seed / directo en la base — no hay registro público
para ninguno de estos roles).

## Variables de entorno

**backend/.env** (ver `backend/.env.example`):

```
PORT=3000
NODE_ENV=development
DB_CLIENT=sqlite            # sqlite | postgres
SQLITE_FILE=./data/escuela.sqlite3
DATABASE_URL=postgresql://usuario:password@localhost:5432/escuela_db
JWT_SECRET=cambiar-este-secreto-en-produccion
JWT_EXPIRES_IN=7d
# Además de habilitar CORS para la API REST, esta URL es la que se le pasa
# a Socket.io como origen permitido para el chat de soporte en vivo — no
# hace falta una variable aparte para eso.
FRONTEND_URL=http://localhost:3500

# --- Mails ---
# Si SMTP_HOST queda vacío, el server arranca en modo prueba (Ethereal):
# no manda nada a casillas reales, y cada mail queda visible con un link
# de vista previa en /admin-panel/mails → Registro. Para mandar mails de
# verdad, completá estos 5 campos con los datos de tu proveedor (Gmail,
# SendGrid, un SMTP propio, etc.). Este proyecto ya tiene esto completo en
# su backend/.env real (Hostinger, cuenta test@aiviento.com) — el ejemplo
# de abajo queda vacío a propósito porque .env no se versiona:
SMTP_HOST=
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=
SMTP_PASS=
MAIL_FROM_NAME=Escuela Online
MAIL_FROM_EMAIL=no-responder@escuela-online.demo
# Los jobs programados (carrito abandonado, inactividad, recordatorio de
# turno) corren cada vez que arranca el server con "npm run dev"/"npm
# start". Poné esto en "false" si necesitás levantar el server sin que
# disparen (por ejemplo, en un script puntual):
JOBS_HABILITADOS=true
```

**Importante:** si `NODE_ENV=production` y `JWT_SECRET` quedó en el valor
por defecto del repo, el server **no arranca** (`process.exit(1)`, ver
`config/env.js`) — con ese secreto conocido cualquiera puede firmar tokens
válidos como cualquier usuario, admin incluido, así que no es algo que se
pueda dejar pasar con un warning. En desarrollo (`NODE_ENV=development` o
`test`) no aplica, para no trabar el día a día. Los jobs programados y el
envío de mails tampoco corren durante `npm test` (ver "Sistema de mails").

**frontend/.env** (ver `frontend/.env.example`):

```
VITE_API_URL=http://localhost:3000/api
```

### Migrar de SQLite a PostgreSQL

1. Instalar Postgres (local o Docker) y crear la base:
   ```powershell
   docker run --name pg-escuela -e POSTGRES_PASSWORD=postgres -e POSTGRES_DB=escuela_db -p 5432:5432 -d postgres
   ```
2. En `backend/.env`, cambiar `DB_CLIENT=postgres` y completar
   `DATABASE_URL`.
3. Instalar el driver de Postgres: `npm install pg`.
4. Correr `npm run migrate` y `npm run seed` de nuevo. El resto del código
   (controllers, models) no necesita ningún cambio: todos hablan con knex,
   no con el driver de la base directamente.

## Estructura del backend

```
backend/src/
├─ app.js                  # punto de entrada, súper comentado
├─ config/                 # env.js, db.js
├─ db/                     # knexfile.js, migrations/, seeds/
├─ controllers/            # lógica de cada endpoint
├─ routes/                 # definición de rutas por dominio
├─ middlewares/             # auth (JWT + roles), errores, upload (multer)
├─ models/                 # acceso a datos (una capa fina sobre knex)
├─ services/                # payments.service.js, cv.service.js, storage.service.js, mail.service.js
├─ jobs/                    # tareas programadas (node-cron): carrito abandonado, inactividad, recordatorio de turno
├─ realtime/                # chatSocket.js — chat de soporte en vivo (Socket.io)
└─ utils/                   # roles.js, contentTipos.js, migrationStatus.js
```

## Funcionalidades y endpoints principales

| Área          | Endpoints                                                      |
|---------------|------------------------------------------------------------------|
| Auth          | `POST /api/auth/register`, `/login` (ambos con rate limit por IP — 20/hora y 10/15min respectivamente), `GET /api/auth/me`, `POST /api/auth/verify-email`, `POST /api/auth/resend-verification` (rate limit 8/15min) |
| Perfil        | `GET/PUT /api/users/profile`                                    |
| Tienda        | `GET /api/courses` (solo estado "subido"), `GET /api/courses/:id`, `GET /api/courses/categories` (lista fija de categorías), `GET /api/courses/teaching` (profesor: los suyos, cualquier estado), `POST /api/courses` (profesor) |
| Inscripción   | `POST /api/courses/:id/enroll` (compra directa, pago simulado — rechaza si el curso no está "subido"), `GET /api/courses/mine` (excluye "fuera_sistema") |
| Carrito       | `GET /api/cart`, `POST /api/cart/items`, `DELETE /api/cart/items/:courseId`, `POST /api/cart/checkout` (alumno) |
| Classroom     | `GET/POST /api/classroom/courses/:courseId/assignments`, `POST /api/classroom/assignments/:id/submissions` (archivo), `GET .../submissions`, `PUT /api/classroom/submissions/:id/grade` |
| Temario (curriculum) | `PUT /api/classroom/courses/:id/settings` (modo de avance), `GET .../curriculum`, `POST/GET/PUT/DELETE /api/classroom/units[/:unitId]`, `POST/GET/PUT/DELETE /api/classroom/units/:unitId/chapters` \| `/chapters/:id`, `POST .../chapters/:id/progress` \| `/complete`, `POST/DELETE .../chapters/:id/files` \| `/chapter-files/:id`, `GET/POST/DELETE .../chapters/:id/comments` \| `/comments/:id`, `PUT .../comments/:id/visibility` (ocultar/mostrar sin borrar) — ver detalle abajo |
| Logros        | `GET /api/achievements`, `GET /api/achievements/mine`           |
| Contacto      | `POST /api/contact`                                              |
| Creador de CV | `POST /api/cv/generate` → devuelve un PDF                        |
| Completar curso | `GET /api/classroom/courses/:id/students`, `PUT .../students/:userId/complete` (profesor del curso o admin) |
| Contenido público | `GET /api/content` → textos/imágenes editables para Home/Contacto/Footer |
| Profesores (listado) | `GET /api/users/profesores` → cualquier usuario logueado, para elegir con quién pedir un turno |
| Calendario    | `GET /api/calendar/mis-turnos`, `POST /api/calendar/turnos` (alumno), `PUT /api/calendar/turnos/:id/aceptar` \| `/rechazar` \| `/cancelar` |
| **Admin**     | `GET /api/admin/dashboard`, `GET/POST /api/admin/users` (`?rol=alumno\|profesor\|admin\|todos`), `GET/POST/PUT /api/admin/courses`, `GET/PUT /api/admin/content`, `POST /api/admin/upload-imagen`, `GET /api/admin/calendario`, `GET/POST/PUT/DELETE /api/admin/nav-links`, `GET/POST/PUT/DELETE /api/admin/botones`, `GET /api/admin/errores` (`?page=`, paginado de a 20), `DELETE /api/admin/errores` (limpia el registro), `GET /api/admin/logins`, `GET /api/admin/testing/suites`, `POST /api/admin/testing/run/:id` (todo protegido por rol admin) |
| **Admin — Mails** | `GET/PUT /api/admin/mails/plantillas[/:clave]`, `POST /api/admin/mails/plantillas/:clave/probar`, `GET/PUT /api/admin/mails/configuracion[/:clave]`, `GET /api/admin/mails/registro`, `GET/POST/PUT/DELETE /api/admin/mails/listas[/:id]`, `GET/POST /api/admin/mails/listas/:id/miembros`, `POST /api/admin/mails/listas/:id/miembros/todos`, `DELETE /api/admin/mails/listas/:id/miembros/:userId` \| `/todos`, `POST /api/admin/mails/listas/:id/enviar` (todo protegido por rol admin) |
| Chat (alumno/profesor) | `GET /api/chat/mi-conversacion` → historial propio (mandar mensajes es por socket, ver "Chat de soporte en vivo") |
| Chat (soporte) | `GET /api/soporte/conversaciones?estado=`, `GET /api/soporte/conversaciones/:id/mensajes` (protegido por rol soporte; responder/cerrar es por socket) |
| **Admin — Chats** | `GET /api/admin/chats?estado=`, `GET /api/admin/chats/:id/mensajes` → registro de solo lectura de todas las conversaciones (protegido por rol admin) |
| Salud del server | `GET /api/health` → estado general + si hay migraciones sin correr (`migraciones.pendientes`) |

Roles: **alumno**, **profesor**, **admin** y **soporte**. Un profesor crea
tareas, revisa/califica entregas, marca cursadas como completadas y
acepta/rechaza turnos; un alumno se inscribe, entrega tareas, junta logros
y pide turnos con sus profesores; un admin gestiona todo desde el panel
(ver abajo); un agente de soporte solo ve y responde el chat en vivo desde
su propio panel (`/soporte`), no tiene acceso a nada más de la plataforma.

### Validación de cuenta por mail

Al registrarse, además de devolver el token de sesión de siempre (el
registro sigue logueando automáticamente — **no es un gate**, es
informativo), se manda un mail con un **código de 6 dígitos** (`plantilla
verificacion_cuenta`, vence a los 15 minutos, máximo 5 intentos). Mientras
la cuenta no esté validada, el alumno/profesor ve un banner en `/panel`
con un link a `/verificar-email` para cargar el código o pedir uno nuevo
("Reenviar código"). Al validar, se manda el mail de `bienvenida`. Ni el
registro ni el login dependen de este estado — es puramente informativo,
a propósito, para no romper el flujo de "me registro y ya puedo usar la
plataforma" que ya estaba probado.

### Carrito de compras

Persistente en la base (no en el navegador), para que el server pueda
detectar abandono sin depender del cliente: cada alumno tiene **un
carrito activo** a la vez (`carts.estado = 'activo'`, un alumno puede
tener varios carritos históricos — convertidos o abandonados — pero solo
uno activo, garantizado a nivel de código, no de constraint de base). El
checkout paga cada item del carrito (mismo `payments.service.js` simulado
que la compra directa), otorga el logro de "primer curso" si corresponde,
manda un único mail de `confirmacion_compra` resumiendo toda la compra, y
vacía el carrito marcándolo `convertido`. Si algún curso del carrito ya
estaba comprado al momento del checkout, se salta (no se cobra dos veces)
y se informa en la respuesta.

### Temario del curso (unidades, capítulos y avance)

Cada curso tiene un temario propio, jerárquico: **curso → unidades →
capítulos** (tablas `course_units`, `course_chapters`). El profesor dueño
del curso lo arma desde `/classroom/:courseId` → pestaña "Contenido del
curso"; el admin tiene su propia puerta de entrada equivalente desde
`/admin-panel/cursos` → botón **"Contenido"** de cada curso
(`AdminCourseCurriculum.jsx`, `/admin-panel/cursos/:id/temario`) — reusa el
mismo editor (`CurriculumEditor.jsx`), sin cambios del lado del backend,
porque el login de admin pasa por el mismo `/api/auth/login` y ya cumple
el chequeo de "profesor dueño o admin" (`checkGestionAcceso`). El botón
**"Editar"**, al lado, sigue siendo para el título/descripción/precio/
portada del curso — son dos pantallas separadas a propósito.

- **Unidad**: título + introducción + "qué vas a ver en esta unidad"
  (texto libre). Tiene su propia página de detalle (`/classroom/:courseId/
  unidades/:unitId`) con esos dos textos y la lista de sus capítulos.
- **Capítulo**: título + link de video de **YouTube o Vimeo** (se pega el
  link normal, tipo `youtube.com/watch?v=...` o `vimeo.com/...` — el
  proveedor se detecta solo). También soporta **Vimeo privado**, que trae
  un hash extra al final del link (`vimeo.com/123456789/abcd1234ef`, o ya
  en formato embed `player.vimeo.com/video/123456789?h=abcd1234ef`) — sin
  ese hash el video no reproduce aunque el id sea correcto; se detectan
  los dos formatos (`VideoPlayer.jsx::parseVideoUrl`). No se sube el
  archivo de video en sí: se eligió link externo a propósito, porque el
  storage de esta app es disco local (ver "Storage de archivos" más
  arriba, en Stack) y un video pesa mucho más que lo que ese storage está
  pensado para aguantar. Cada capítulo tiene también, si el profesor sube
  algo, una sección de **archivos de utilidad** (apuntes, código,
  planillas — cualquier tipo, hasta 25MB) — si no tiene ninguno, esa
  sección directamente no aparece en la página del capítulo.
- La página del capítulo (`/classroom/:courseId/unidades/:unitId/
  capitulos/:chapterId`) y la de la unidad tienen, al costado, una barra
  de navegación con el título del curso y el temario completo
  (unidades + capítulos, con el actual resaltado y los bloqueados
  marcados con 🔒 sin ser clickeables — `CourseSidebar.jsx`, se apila
  arriba del contenido en pantallas angostas). La página del capítulo
  además tiene: el video embebido, una caja de comentarios, botones
  **Anterior/Siguiente**, la sección de archivos de utilidad (si tiene), y
  una línea de tiempo con el % de avance de la unidad.
- **Comentarios y moderación**: cualquiera con acceso al classroom
  (alumno inscripto o el profesor) puede comentar y borrar el suyo. Desde
  el editor del temario (tanto el del profesor como el del admin, mismo
  componente), quien gestiona el curso ve además, por capítulo, la lista
  completa de comentarios con opción de **responder** (queda anidada bajo
  la pregunta) y de **ocultar** un comentario puntual sin borrarlo — el
  registro queda en la base, pero deja de mandarse en la respuesta de
  `GET .../comments` para cualquiera que no gestione el curso (no es un
  filtro del front: un alumno no recibe ese comentario ni aunque
  inspeccione la respuesta de la API). El mismo botón lo vuelve a
  mostrar. Solo el profesor dueño o un admin pueden ocultar/mostrar
  (`PUT .../comments/:id/visibility`); borrar sigue disponible aparte
  (autor del comentario, o gestor del curso) y es definitivo.

**Progreso de video real, no solo "abrió la página":** se usa la API
oficial de cada proveedor (IFrame API de YouTube, Player.js de Vimeo) para
saber cuánto se vio de verdad. Se guarda el **segundo máximo alcanzado**
(no el último reportado), para que adelantar y volver atrás no haga bajar
el progreso ya ganado. Toda la regla vive en el backend
(`src/services/curriculum.service.js`) — el frontend nunca decide por su
cuenta si un capítulo se puede marcar como visto, siempre se lo pregunta
al servidor.

**Configuración por curso** (el profesor dueño o un admin la cambian
desde la misma pestaña):

- **Exigir 80% visto** (on/off): si está activo, un capítulo recién se
  puede marcar como "visto" al haber visualizado el 80% del video. Si el
  profesor lo desactiva, se puede marcar como visto en cualquier momento.
- **Modo de avance**, tres opciones:
  - `libre` — el alumno puede ver cualquier capítulo de cualquier unidad,
    en el orden que quiera.
  - `por_unidad` — el primer capítulo de **cada** unidad está siempre
    desbloqueado (se puede arrancar cualquier unidad), pero dentro de una
    unidad hay que completar el capítulo N para que se desbloquee el N+1.
  - `continuo` — estrictamente lineal: solo está desbloqueado el capítulo
    siguiente al último completado, en todo el curso (cruza unidades sin
    poder saltar ninguna).

Completar todos los capítulos del curso otorga el logro de "curso
completado" automáticamente (el mismo que ya otorgaba el profesor a mano
desde "Alumnos inscriptos" — ahora también se gana solo con el temario).

### Sistema de mails

Motor propio (`mail.service.js`) que **nunca tira una excepción**: si
falla el envío (o la plantilla está inactiva/no existe), queda registrado
en `mail_log` con el error y el flujo de negocio que lo disparó (compra,
registro, turno, etc.) sigue funcionando igual — mismo criterio que ya se
usaba para el registro de logins.

**Modo de envío:** si no hay `SMTP_HOST` configurado, arranca en modo
prueba con [Ethereal](https://ethereal.email/) (una casilla descartable
que Nodemailer crea sola) — no sale ningún mail real, y cada envío queda
en el Registro con un link para ver cómo hubiese quedado. Con `SMTP_HOST`
completo pasa a mandar por ese proveedor de verdad. El backoffice
(`/admin-panel/mails` → Plantillas) muestra en qué modo está corriendo.
**Este proyecto ya tiene un SMTP real configurado** (Hostinger, cuenta
`test@aiviento.com`, `backend/.env` — no versionado) — todo mail que
mande la plataforma sale de verdad, salvo que el modo prueba de
redirección de abajo esté activo.

**Modo prueba de redirección** (`app_settings.mail_modo_prueba_destinatario`,
editable en Configuración — ver bullet de abajo): mientras tenga un email
cargado, **todo mail que la plataforma quiera mandar** (de negocio —
verificación, compra, turnos— o el botón "Probar" de una plantilla) se
redirige de verdad a esa casilla en vez del destinatario real. Pensado
para validar un SMTP recién conectado sin mandarle nada a alumnos o
profesores de verdad. `mail_log.destinatario` queda con la dirección a la
que se mandó de verdad; la nueva columna `mail_log.redirigido_desde`
guarda para quién era en realidad (`null` en un envío sin redirección).
Se apaga guardando el campo vacío en Configuración — ahí vuelve a
respetarse el destinatario real de cada mail.

**Los 10 mails de la plataforma** (plantilla + disparador):

| Plantilla              | Se manda cuando...                                              |
|-------------------------|-------------------------------------------------------------------|
| `verificacion_cuenta`   | se registra una cuenta nueva (código de 6 dígitos)                |
| `bienvenida`             | se valida el código de verificación                               |
| `carrito_abandonado`     | un carrito queda sin actividad más de N horas (job programado)    |
| `confirmacion_compra`    | se completa una compra (carrito o directa)                        |
| `te_extranamos`          | un alumno/profesor no inicia sesión hace más de N días (job)      |
| `felicitaciones_curso`   | un profesor marca un curso como completado para un alumno         |
| `cita_creada`            | un alumno solicita un turno (a alumno y profesor)                  |
| `cita_aprobada`          | el profesor acepta un turno (a alumno y profesor)                  |
| `recordatorio_cita`      | faltan N minutos para un turno aceptado (job programado)          |
| `oferta_aviso`           | el admin manda un aviso a una lista desde el backoffice           |

**Jobs programados** (`backend/src/jobs/`, con `node-cron`, arrancan solo
si `JOBS_HABILITADOS=true` y **nunca** durante `npm test` — están
enganchados al mismo bloque de `app.js` que ya arrancaba el server, así
Jest jamás los dispara):

| Job                        | Frecuencia   | Umbral (editable en Configuración) |
|-----------------------------|--------------|--------------------------------------|
| `carritoAbandonado.job.js`  | cada 30 min  | `horas_carrito_abandonado` (default 24) |
| `inactividad.job.js`        | diario 9am   | `dias_inactividad_te_extranamos` (default 30) |
| `recordatorioCitas.job.js`  | cada 5 min   | `minutos_recordatorio_cita` (default 30) |

### Backoffice de mails (`/admin-panel/mails`)

Cuatro pestañas, todas dentro del panel de admin (rol `admin`):

- **Plantillas:** editar asunto y cuerpo (HTML simple, con variables tipo
  `{{nombre}}`) de cada uno de los 10 mails, activar/desactivar cada uno
  individualmente, y un botón **"Probar"** que manda esa plantilla con
  valores de ejemplo (sin tener que disparar el flujo real — comprar un
  curso, pedir un turno, etc.) y muestra el link de vista previa si está
  en modo prueba.
- **Configuración:** los 3 umbrales de arriba (días de inactividad, horas
  de carrito abandonado, minutos de recordatorio) más el **modo prueba de
  redirección** (ver más arriba), todos editables sin necesitar un
  redeploy. Guardar el campo del modo prueba vacío lo apaga (el endpoint
  acepta explícitamente un valor vacío para este caso puntual — ver nota
  en `mails.controller.js::updateSetting`).
- **Listas:** listas armables a mano (crear, borrar, agregar/quitar
  alumnos y profesores uno por uno o con **"Seleccionar todos" /
  "Quitar todos"**) para el mail de ofertas/avisos. La plantilla
  `oferta_aviso` define el look general; el **título y el mensaje** de
  cada envío se escriben en esta misma pestaña al mandarlo — así una
  misma plantilla sirve tanto para "Black Friday" como para un aviso de
  mantenimiento, sin tocar código.
- **Registro de envíos:** todos los mails que la plataforma intentó
  mandar (transaccionales y de campaña), filtrable por tipo y estado, con
  link a la vista previa cuando corresponde — la forma de confirmar que
  un mail realmente se disparó sin abrir una casilla real.

### Chat de soporte en vivo

Único rincón de la app que no es REST puro: un widget de chat flotante
(💬, abajo a la derecha) visible en cualquier página del sitio público
para **alumnos y profesores logueados** (no para visitantes anónimos, ni
para admin — cada uno tiene su propia forma de interactuar con esto)
habla en tiempo real, por WebSockets (Socket.io), con el panel de
agentes de soporte en `/soporte`.

- **Cómo arranca una conversación:** sola, con el primer mensaje que
  escribe el alumno/profesor — no hay un botón separado de "iniciar
  chat". Si ya tenía una conversación abierta, sigue ahí; si la anterior
  ya se había cerrado, escribir de nuevo abre una nueva.
- **Cola compartida, no asignación:** cualquier agente de soporte
  conectado en `/soporte` ve TODOS los chats (abiertos y cerrados) y
  puede responder cualquiera — no hay "este chat es mío, no tuyo". El
  campo "atendido por" que se ve en la lista es solo informativo (el
  último agente que respondió), pensado para que el equipo sepa quién ya
  le puso el ojo a cada uno, no para bloquear a los demás.
- **Cerrar un chat** es una acción exclusiva de soporte (un alumno no
  puede cerrar su propia conversación). Un chat cerrado no acepta más
  mensajes de soporte; si el alumno vuelve a escribir, se le abre uno
  nuevo automáticamente.
- **Cuentas de soporte:** las crea un admin desde
  `/admin-panel/soporte` (mismo patrón que Profesores) e inician sesión
  en `/soporte/ingresar` — login propio, con su propia sesión
  (`soporte_token` en `localStorage`), igual que el panel de admin tiene
  la suya (`admin_token`). Una cuenta de soporte no puede entrar por el
  login público (`/ingresar`) y viceversa.
- **Qué ve el admin:** un registro de solo lectura en
  `/admin-panel/chats` — todas las conversaciones, con quién habló, quién
  la atendió, cuántos mensajes tiene y la transcripción completa de
  cualquiera. El admin no responde desde ahí, solo supervisa.
- **Por qué WebSockets y no "refrescar cada tanto":** un chat en vivo
  necesita que el mensaje aparezca del otro lado al instante, sin que
  nadie tenga que recargar la página — eso es justo lo que un socket
  permite y un fetch normal no. El resto de la app (mails, carrito,
  calendario...) sigue siendo REST puro a propósito: los sockets solo se
  usan acá, donde de verdad hacen falta.
- **Qué es REST y qué es socket:** cargar el historial al abrir la
  página (`GET /api/chat/mi-conversacion`, `GET /api/soporte/
  conversaciones[/:id/mensajes]`, `GET /api/admin/chats[/:id/mensajes]`)
  es todo REST normal — los sockets (`backend/src/realtime/
  chatSocket.js`) se usan solo para lo que tiene que sentirse instantáneo:
  mandar un mensaje y cerrar un chat.

### Calendario de turnos (`/calendario`)

Página privada para alumno y profesor (no para admin, que tiene su propia
vista de solo lectura, ver más abajo):

- El **alumno** elige un profesor (y opcionalmente un curso propio), un
  motivo y un horario, y solicita el turno. Queda en estado `pendiente` y
  se manda el mail `cita_creada` a ambas partes.
- El **profesor** ve las solicitudes pendientes y las acepta o rechaza
  (con una nota opcional). Al aceptar se manda el mail `cita_aprobada` a
  ambas partes. También ve su agenda ya confirmada.
- Cualquiera de las dos partes puede **cancelar** un turno pendiente o ya
  aceptado.
- **Que no se sobrepongan** se garantiza a nivel de base de datos: no se
  puede solicitar (ni aceptar) un turno cuyo horario se cruza con otro
  turno ya `aceptado` del mismo profesor (`calendarEvent.model.js →
  hasOverlap`). El chequeo corre tanto al solicitar como al aceptar, para
  cubrir el caso de dos solicitudes pendientes que se superponen entre sí
  (el profesor solo puede confirmar una).
- 30 minutos antes de un turno aceptado, el job `recordatorioCitas.job.js`
  manda `recordatorio_cita` a ambas partes (una sola vez por turno).

## Frontend — páginas

Públicas: Home, Contacto, Tienda de cursos, Detalle de curso, Términos y
condiciones, Login, Registro.

Privadas (requieren login): Panel (intro, con banner de validación de
cuenta si corresponde), Verificar email, Perfil, Mis cursos, Carrito
(exclusiva de alumnos), Classroom (vista distinta para alumno/profesor,
incluye marcar cursada completada), Calendario (turnos alumno-profesor,
vista distinta según rol), Creador de CV. Logros y Carrito son privadas y
exclusivas de alumnos.

El menú de navegación y el panel/intro (`/panel`) también cambian según el
rol: alumno y profesor no ven las mismas opciones, porque cumplen
funciones distintas en la plataforma (ver `Navbar.jsx` y `UserHome.jsx`).
El ícono de carrito en el menú (con contador) solo aparece para alumnos.

Además, en **todas** las páginas públicas y privadas (vía `Layout.jsx`) hay
un widget flotante de **chat de soporte** (💬, abajo a la derecha), visible
solo para alumnos y profesores logueados — ver "Chat de soporte en vivo"
más arriba para el detalle completo.

## Panel de administración (`/admin-panel`)

Área separada del sitio público, con su propio login (`/admin-panel/ingresar`)
y layout (sidebar), protegida por rol `admin`:

- **Dashboard** (`/admin-panel`): cursos vendidos, alumnos, cursos
  completados, tareas revisadas, y una tabla de profesores con cursos que
  dictan y tareas revisadas/pendientes.
- **Profesores** (`/admin-panel/profesores`): alta de cuentas de profesor
  (única forma de crearlas) y listado de las existentes.
- **Agentes de soporte** (`/admin-panel/soporte`): alta de cuentas de
  soporte (mismo patrón que Profesores — es la única forma de crearlas) y
  listado de las existentes. Reutiliza el endpoint genérico
  `GET/POST /api/admin/users?rol=soporte`, sin lógica nueva del lado del
  backend.
- **Chats** (`/admin-panel/chats`): registro de solo lectura de todas las
  conversaciones del chat de soporte (abiertas y cerradas), filtrable por
  estado, con la transcripción completa de cualquiera expandible por fila
  — ver "Chat de soporte en vivo" más arriba.
- **Cursos** (`/admin-panel/cursos`): crear cursos nuevos (asignando
  profesor) y editar los existentes, con subida de imagen de portada. El
  botón **"Contenido"** de cada fila abre el editor del temario completo
  (unidades, capítulos, videos, archivos de utilidad y comentarios — ver
  "Temario del curso" más abajo), para no depender de que el admin tenga
  sesión como profesor en algún classroom. Dentro del formulario de
  edición hay además un link directo **"Editar contenido del curso →"**
  al lado del título — antes, para pasar de editar los datos del curso a
  editar su temario había que cerrar el formulario y volver a buscar el
  botón "Contenido" en la fila; ahora es un solo click sin salir de la
  edición en curso.
  - **Categoría**: desplegable con una lista fija (`backend/src/config/
    categorias.js`, servida en `GET /api/courses/categories`) — antes era
    texto libre, lo que permitía inconsistencias (mayúsculas distintas,
    typos) entre cursos. El backend no rechaza una categoría que no esté
    en la lista al guardar (para no romper un curso viejo con una
    categoría que ya no está ahí), así que la lista es un control del
    lado del formulario, no una restricción dura de la base.
  - **Estado** (`backend/src/config/estadosCurso.js`, columna
    `courses.estado`): otro desplegable, con cuatro valores —
    **Subido** (normal: visible en la tienda y comprable), **En
    revisión** (no aparece en la tienda ni se puede comprar),
    **Cancelado** (no se puede comprar más, pero un alumno que ya lo
    tenía comprado sigue con acceso normal al classroom — no se le saca
    nada) y **Fuera de sistema** (no lo ve nadie, ni siquiera un alumno
    que ya lo había comprado — el profesor dueño y el admin son la única
    excepción, para poder reactivarlo). La tabla de cursos muestra el
    estado de cada uno con un badge de color. Esta lógica se valida del
    lado del servidor en varios puntos a la vez, no solo ocultando cosas
    en el front: `courses.controller.js` (catálogo público y compra
    directa), `cart.controller.js` (agregar al carrito y checkout),
    `classroom.controller.js`/`curriculum.controller.js` (acceso al
    classroom y al temario) y `enrollment.model.js` ("mis cursos").
- **Contenido del sitio** (`/admin-panel/contenido`): dividido en
  sub-pestañas, una por página pública más "Generales". Todo el registro de
  campos vive en `frontend/src/config/content.js` (`CONTENT_PAGES`) — para
  agregar un campo nuevo alcanza con sumarlo ahí y leerlo con `useContent()`
  en la página pública correspondiente.
  - **Generales**: logo + alt, **logo para fondos oscuros** (opcional —
    variante clara para el footer/secciones oscuras; si no se carga, cae al
    logo normal, ver `Footer.jsx`), **favicon** (PNG o SVG, se aplica tanto
    al sitio público como al panel de admin — es el único campo de este
    grupo que sí corre en el admin, ver nota de alcance más abajo),
    tipografía de títulos/texto (lista curada de Google Fonts, se aplica a
    todo el sitio público vía `useFonts()`), **4 colores globales**
    (primario, acento, fondo oscuro, texto sobre fondo oscuro — se aplican
    como variables CSS en `:root` vía `useTheme()`, mismo mecanismo que
    `useFonts()`: si no se carga un color queda el default de
    `global.css`), sufijo de título y meta descripción por defecto (SEO),
    links extra de menú/footer (además de la navegación funcional por rol,
    que sigue en código), y el **registro de botones**: cada "Opción N"
    define color de fondo, color de texto y link — se define acá una sola
    vez y se reutiliza en cualquier página.

  **La identidad visual por defecto es la de [aiviento.com](https://aiviento.com)**
  — negro (`#000000`) como color primario, verde lima (`#a5e84f`) como
  acento, secciones oscuras en negro puro con texto blanco, y las mismas
  tipografías (Syne/Inter) y logo (wordmark AIVIENTO, con una variante
  clara embebida como `data:image/png;base64,...` para el footer). Estos
  son los `default` de cada campo en `frontend/src/config/content.js` —no
  filas en la base— así que un sitio recién instalado, o uno cuya tabla
  `site_content` está vacía, arranca automáticamente con esta identidad
  sin que el admin tenga que cargar nada. Si el admin edita un color/logo
  desde este panel, esa fila en la base pisa el default; si más adelante
  se quiere volver a la identidad de aiviento alcanza con borrar esa fila
  (o dejar el campo en blanco al editar). `global.css` tiene los mismos
  valores como fallback de CSS puro (por si el JS de `useTheme()`/
  `useFonts()` todavía no corrió).
  - **Home / Contacto / Tienda / Detalle de curso / Términos / Ingresar /
    Crear cuenta**: cada una en su propia sub-pestaña, con sus textos,
    imágenes, color de fondo/acento y SEO propio (título + meta
    descripción, con fallback al de Generales). Los botones de cada página
    tienen un selector para elegir qué "Opción N" del registro usan. Los
    botones que disparan una acción (enviar el formulario, comprar,
    ingresar, crear cuenta) solo toman el **color** de la opción elegida —
    el link queda fijo en código porque no tendría sentido que un botón de
    "Enviar mensaje" navegue a otro lado en vez de mandar el formulario.
    Tienda no tiene un botón asignable porque cada tarjeta de curso es
    dinámica (no hay "el botón" fijo de esa página).
- **Mails** (`/admin-panel/mails`): backoffice completo del sistema de
  mails — ver "Backoffice de mails" más arriba.
- **Calendario** (`/admin-panel/calendario`): registro de **todos** los
  turnos solicitados en la plataforma (alumno, profesor, curso, horario,
  motivo y estado), con filtro por estado. Es de solo lectura — aceptar,
  rechazar o cancelar sigue siendo cosa del alumno y el profesor
  involucrados, no del admin.
- **Errores** (`/admin-panel/errores`): registro de errores 5xx reales de
  la aplicación, capturados automáticamente por el `errorHandler` central
  (`backend/src/middlewares/error.middleware.js`). A propósito no incluye
  errores 4xx (permisos, validaciones de negocio como "ya estás
  inscripto"): esos son parte del uso normal y llenarían el registro de
  ruido. Filtrable por rango de fechas, **paginado de a 20** (`GET
  /api/admin/errores` acepta `page` y devuelve `{errores, total, page,
  totalPages}` — ver `errorLog.model.js::listPage`), con controles
  "← Anterior" / "Siguiente →" y el total a la vista. Tiene además un
  botón **"Limpiar registro"** (con confirmación) que borra todas las
  filas — pensado para arrancar de cero después de resolver una tanda de
  errores conocidos; se deshabilita solo si el registro ya está vacío.
- **Logins** (`/admin-panel/logins`): cuándo inició y cuándo terminó cada
  conexión de cada usuario, filtrable por usuario y por rango de fechas.
  Con JWT no hay sesión server-side: el "fin" se marca cuando el usuario
  aprieta "Cerrar sesión" (`POST /api/auth/logout`); si cierra la pestaña
  sin desloguearse, la fila queda como "Sesión activa" — es una limitación
  honesta de JWT, no un bug.

- **Testing** (`/admin-panel/testing`): corre la suite real de Jest del
  backend (`backend/tests/`) con un click, cada suite contra su propia base
  SQLite descartable — no toca los datos reales de la app ni reinicia el
  server (`nodemon.json` ignora `data/*` y `**/*.test.js`). Un botón
  "Correr todos los tests" los corre uno por uno y muestra cuántos tests
  pasaron por suite; si alguno falla, se puede expandir para ver el mensaje
  de error puntual. Pensado para confirmar rápido que un cambio no rompió
  nada, sin abrir una terminal. El código vive en
  `backend/src/controllers/testing.controller.js` (agregar un archivo de
  test nuevo en `backend/tests/` es sumar una línea al array `SUITES` ahí)
  — ya incluye las suites de **carrito**, **mails** y **chat de soporte**
  (esta última con sockets reales, ver "Tests" más abajo).
  Sigue sin haber tests end-to-end de navegador (tipo Playwright): lo que
  cubre esta suite es a nivel API/lógica de negocio, no la UI en sí.

**Nota de alcance:** la tipografía/colores/botones del panel de admin en
sí (sidebar, dashboard, etc.) NO se re-temean con este sistema — es una
herramienta funcional aparte, a propósito visualmente distinta del sitio
público (mismo criterio que ya se había tomado para el layout). Tampoco se
aplica a las pantallas internas del alumno/profesor logueado (Mis cursos,
Classroom, CV, Perfil, Calendario, Carrito): el pedido original hablaba de
logo/menú/footer/SEO, que son conceptos del sitio público. Si en algún
momento se quiere extender el mismo mecanismo a esas pantallas, es
agregar campos nuevos a `CONTENT_PAGES` — la arquitectura ya lo soporta.

La **única excepción** es el favicon: a diferencia de `useTheme()`/
`useFonts()`, `useFavicon()` también se llama desde `AdminLayout.jsx`,
porque el ícono de la pestaña del navegador identifica la pestaña en sí,
no es parte del "look" de una sección — tiene sentido que sea el mismo en
todo el sitio, admin incluido.

## Tests

```powershell
cd "C:\Users\Dba24\Desktop\escuela-app\backend"
npm test
```

Cubre el flujo de registro/login (incluyendo la validación de cuenta por
código de 6 dígitos), creación de curso → inscripción (compra simulada) →
logro otorgado automáticamente, el carrito de compras (agregar/quitar
items, checkout, cursos ya comprados), el panel de admin (permisos, alta
de profesor, alta/edición de curso, edición de contenido, dashboard), el
backoffice de mails (plantillas, configuración, listas con
seleccionar/quitar todos, registro de envíos, y el modo prueba de
redirección: activarlo, confirmar que un envío queda redirigido con
`redirigido_desde` registrado, y volver a apagarlo), el calendario de
turnos (solicitar, aceptar, rechazar, cancelar, permisos por
rol/titularidad, y el chequeo de superposición de horarios), el
backoffice general (links de menú/footer, registro de botones,
validación de tipos de contenido, captura automática de errores 5xx con
su paginado de a 20 y el botón de limpiar registro, y el registro de
logins con apertura/cierre de sesión y filtros), el rate limiting de
login, el chat de soporte en vivo (permisos por rol, cola compartida,
cierre, y aislamiento entre conversaciones), las rutas del propio panel
de Testing, y el temario de cursos (unidades/capítulos, los tres modos de
avance con su regla del 80%, progreso de video, comentarios —incluida la
moderación: responder y ocultar/mostrar sin borrar— y archivos de
utilidad, tanto la lógica pura en `curriculum.service.js` como los
endpoints de punta a punta), y los cuatro estados de curso (visibilidad en
la tienda, bloqueo de compra, y quién mantiene o pierde el acceso al
classroom en cada uno). **137 tests, 12 suites, todo verde.**

La suite de chat (`chat.test.js`) es una excepción a la falta de tests de
navegador de más abajo: en vez de solo pegarle a los endpoints REST,
levanta un servidor HTTP real y conecta clientes de `socket.io-client` de
verdad (alumno, soporte y admin) para probar el flujo completo en vivo —
mandar y recibir mensajes por socket, cerrar un chat, y que un alumno no
pueda meterse en la conversación de otro — no solo que la lógica de
negocio esté bien, sino que la infraestructura de WebSockets en sí
funciona de punta a punta.

Los jobs programados y el envío real de mails (SMTP) **no** corren durante
los tests: los jobs solo arrancan si el módulo se ejecuta como server real
(`require.main === module`, mismo guard que ya usaba `app.listen()`), y
`mail.service.js` en modo prueba tampoco toca la red real salvo para crear
la casilla descartable de Ethereal.

También se puede correr suite por suite (o todas) desde el navegador, sin
terminal, en `/admin-panel/testing` (ver sección de Panel de administración
más arriba) — mismo resultado, más cómodo para un chequeo rápido.

## Decisiones y próximos pasos pendientes

- **Pagos reales:** hoy es 100% simulado. `payments.service.js` tiene
  comentado cómo se conectaría Mercado Pago.
- **Envío de emails:** ya está armado el motor completo (verificación,
  carrito abandonado, confirmación de compra, inactividad, felicitaciones,
  turnos, ofertas/avisos a listas) y arranca en **modo prueba** (Ethereal)
  para no mandar nada real por accidente. Para pasar a producción alcanza
  con completar `SMTP_HOST` y compañía en `backend/.env` — no hace falta
  tocar código.
- **Storage de archivos:** las entregas de tareas se guardan en disco local
  (`backend/uploads/`). Ya está aislado en `storage.service.js` para migrar
  a S3 (o similar) sin tocar controllers ni modelos — para producción con
  más de una instancia del server conviene hacerlo, porque disco local no
  se comparte entre instancias ni sobrevive a que se recree el contenedor.
- **Testing end-to-end de navegador:** el panel de Testing (ver arriba)
  cubre auth/cursos/carrito/mails/admin/calendario/backoffice a nivel API
  con Jest, pero no hay todavía algo tipo Playwright que maneje un
  navegador real y reproduzca los flujos completos de UI — lo que se
  probó de esa forma en esta última ronda de QA se hizo a mano, no queda
  automatizado.
- **Frontend/QA:** este README y el código cubren el backend y el frontend
  a nivel funcional; falta una revisión de diseño/UX más fina si se quiere
  llevar a producción.
- **Chat de soporte — alcance actual:** cubre lo pedido (widget en vivo,
  panel de soporte con cola compartida, registro de admin). Cosas que NO
  se pidieron y por eso no están: paginación del historial (hoy carga todo
  el hilo entero, viable mientras las conversaciones sean cortas),
  indicador de "escribiendo…", confirmación de lectura, ni notificaciones
  push cuando soporte está desconectado del panel — si el proyecto crece,
  son las próximas mejoras naturales sobre `chatSocket.js`.
