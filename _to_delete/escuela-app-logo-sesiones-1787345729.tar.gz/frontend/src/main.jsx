import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { AuthProvider } from './context/AuthContext.jsx';
import { AdminAuthProvider } from './context/AdminAuthContext.jsx';
import ErrorBoundary from './components/ErrorBoundary.jsx';
import './styles/global.css';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    {/* Afuera de todo lo demás: si algo rompe el render (bug de un
        componente, error de contexto, lo que sea) el usuario ve una
        pantalla clara en vez de una pantalla en blanco. */}
    <ErrorBoundary>
      <BrowserRouter>
        {/* AuthProvider (sitio público, clave 'token') y AdminAuthProvider
            (panel de admin, clave 'admin_token') se montan los dos juntos,
            siempre, durante toda la vida de la app. Son independientes:
            cada uno guarda su propia sesión, así que se puede estar
            logueado como alumno/profesor Y como admin al mismo tiempo en
            el mismo navegador sin que uno pise al otro. */}
        <AuthProvider>
          <AdminAuthProvider>
            <App />
          </AdminAuthProvider>
        </AuthProvider>
      </BrowserRouter>
    </ErrorBoundary>
  </StrictMode>
);
