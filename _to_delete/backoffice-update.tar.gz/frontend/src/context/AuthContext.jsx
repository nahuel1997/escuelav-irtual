// Contexto global de autenticación. Guarda el usuario logueado y el token,
// persistiendo el token en localStorage para no perder la sesión al
// refrescar la página.
import { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      setLoading(false);
      return;
    }
    api
      .get('/auth/me')
      .then(({ user }) => setUser(user))
      .catch(() => localStorage.removeItem('token'))
      .finally(() => setLoading(false));
  }, []);

  async function login(email, password) {
    const { token, user } = await api.post('/auth/login', { email, password }, { auth: false });
    localStorage.setItem('token', token);
    setUser(user);
    return user;
  }

  async function register(datos) {
    const { token, user } = await api.post('/auth/register', datos, { auth: false });
    localStorage.setItem('token', token);
    setUser(user);
    return user;
  }

  function logout() {
    // Avisamos al backend para que cierre el registro de esta sesión en
    // login_logs (queda con hora de inicio y de fin). Es best-effort: si
    // falla (sin conexión, token ya vencido) igual cerramos la sesión
    // localmente, no tiene sentido bloquear el logout por esto.
    api.post('/auth/logout', {}).catch(() => {});
    localStorage.removeItem('token');
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, setUser, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth debe usarse dentro de un <AuthProvider>');
  return ctx;
}
