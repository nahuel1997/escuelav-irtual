import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import PrivateRoute from './components/PrivateRoute';
import AdminRoute from './components/AdminRoute';
import AdminLayout from './components/AdminLayout';

import Home from './pages/Home';
import Contact from './pages/Contact';
import Login from './pages/Login';
import Register from './pages/Register';
import Store from './pages/Store';
import CourseDetail from './pages/CourseDetail';
import Terms from './pages/Terms';
import UserHome from './pages/UserHome';
import Profile from './pages/Profile';
import MyCourses from './pages/MyCourses';
import Achievements from './pages/Achievements';
import Classroom from './pages/Classroom';
import CvBuilder from './pages/CvBuilder';
import Calendar from './pages/Calendar';
import NotFound from './pages/NotFound';

import AdminLogin from './pages/admin/AdminLogin';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminTeachers from './pages/admin/AdminTeachers';
import AdminCourses from './pages/admin/AdminCourses';
import AdminContent from './pages/admin/AdminContent';
import AdminCalendar from './pages/admin/AdminCalendar';
import AdminErrors from './pages/admin/AdminErrors';
import AdminLogins from './pages/admin/AdminLogins';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        {/* Públicas */}
        <Route path="/" element={<Home />} />
        <Route path="/contacto" element={<Contact />} />
        <Route path="/tienda" element={<Store />} />
        <Route path="/tienda/:id" element={<CourseDetail />} />
        <Route path="/terminos" element={<Terms />} />
        <Route path="/ingresar" element={<Login />} />
        <Route path="/registrarme" element={<Register />} />

        {/* Privadas: cualquier usuario logueado */}
        <Route element={<PrivateRoute />}>
          <Route path="/panel" element={<UserHome />} />
          <Route path="/perfil" element={<Profile />} />
          <Route path="/mis-cursos" element={<MyCourses />} />
          <Route path="/classroom/:courseId" element={<Classroom />} />
          <Route path="/cv" element={<CvBuilder />} />
        </Route>

        {/* Privadas: solo alumnos (logros es un concepto de alumno) */}
        <Route element={<PrivateRoute roles={['alumno']} />}>
          <Route path="/logros" element={<Achievements />} />
        </Route>

        {/* Privadas: alumno y profesor (no admin, que tiene su propia vista
            de calendario dentro del panel de administración) */}
        <Route element={<PrivateRoute roles={['alumno', 'profesor']} />}>
          <Route path="/calendario" element={<Calendar />} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Route>

      {/* Panel de administración: área aparte, con su propio login y layout. */}
      <Route path="/admin-panel/ingresar" element={<AdminLogin />} />
      <Route element={<AdminRoute />}>
        <Route element={<AdminLayout />}>
          <Route path="/admin-panel" element={<AdminDashboard />} />
          <Route path="/admin-panel/profesores" element={<AdminTeachers />} />
          <Route path="/admin-panel/cursos" element={<AdminCourses />} />
          <Route path="/admin-panel/contenido" element={<AdminContent />} />
          <Route path="/admin-panel/calendario" element={<AdminCalendar />} />
          <Route path="/admin-panel/errores" element={<AdminErrors />} />
          <Route path="/admin-panel/logins" element={<AdminLogins />} />
        </Route>
      </Route>
    </Routes>
  );
}
