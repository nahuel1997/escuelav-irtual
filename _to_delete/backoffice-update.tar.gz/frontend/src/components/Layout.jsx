import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import { useContent } from '../hooks/useContent';
import { useFonts } from '../hooks/useFonts';

export default function Layout() {
  // Se pide acá arriba para poder aplicar la tipografía elegida en
  // Generales a todo el sitio público apenas carga cualquier página.
  const { values } = useContent();
  useFonts(values);

  return (
    <>
      <Navbar />
      <main>
        <Outlet />
      </main>
      <Footer />
    </>
  );
}
