import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useContent } from '../hooks/useContent';
import { API_ORIGIN } from '../api/client';

// El menú de navegación depende del rol: alumno y profesor usan la
// plataforma para cosas distintas, así que no tiene sentido mostrarles las
// mismas opciones. Los links públicos (Inicio/Contacto) son para todos.
function getNavLinks(user) {
  const publicos = [
    { to: '/', label: 'Inicio', end: true },
    { to: '/contacto', label: 'Contacto' },
  ];

  if (!user) {
    return [...publicos, { to: '/tienda', label: 'Tienda de cursos' }];
  }

  if (user.rol === 'profesor') {
    return [
      ...publicos,
      { to: '/panel', label: 'Mi panel' },
      { to: '/mis-cursos', label: 'Mis cursos' },
      { to: '/calendario', label: 'Calendario' },
    ];
  }

  // alumno
  return [
    ...publicos,
    { to: '/tienda', label: 'Tienda de cursos' },
    { to: '/panel', label: 'Mi panel' },
    { to: '/mis-cursos', label: 'Mis cursos' },
    { to: '/calendario', label: 'Calendario' },
    { to: '/logros', label: 'Logros' },
    { to: '/cv', label: 'Creador de CV' },
  ];
}

// Los links extra que carga el admin (Generales → Links de menú) pueden
// apuntar afuera del sitio, así que no son siempre un <Link> de router.
function ExtraLink({ url, children }) {
  const esExterno = /^https?:\/\//.test(url);
  if (esExterno) {
    return <a href={url} target="_blank" rel="noreferrer" className="text-muted">{children}</a>;
  }
  return <NavLink to={url} className="text-muted">{children}</NavLink>;
}

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { values: content, navLinks } = useContent();
  const links = getNavLinks(user);
  const extraMenu = navLinks.filter((l) => l.ubicacion === 'menu');

  const logo = content['general.logo'];
  const logoAlt = content['general.logo.alt'] || 'Escuela Online';

  function handleLogout() {
    logout();
    navigate('/');
  }

  return (
    <header style={{ borderBottom: '1px solid var(--color-border)', background: '#fff', position: 'sticky', top: 0, zIndex: 20 }}>
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 68 }}>
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 10, fontFamily: 'var(--font-heading)', fontWeight: 800, fontSize: '1.25rem', color: 'var(--color-primary-dark)' }}>
          {logo ? (
            <img
              src={logo.startsWith('/uploads') ? `${API_ORIGIN}${logo}` : logo}
              alt={logoAlt}
              style={{ height: 34, display: 'block' }}
            />
          ) : (
            'Escuela Online'
          )}
        </Link>

        <nav style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className="text-muted">
              {l.label}
            </NavLink>
          ))}
          {extraMenu.map((l) => <ExtraLink key={l.id} url={l.url}>{l.texto}</ExtraLink>)}
        </nav>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {!user && (
            <>
              <Link to="/ingresar" className="btn btn-outline btn-sm">Ingresar</Link>
              <Link to="/registrarme" className="btn btn-primary btn-sm">Registrarme</Link>
            </>
          )}
          {user && (
            <>
              <Link to="/perfil" className="text-muted" style={{ fontSize: '0.9rem' }}>
                {user.nombre} <span className="badge">{user.rol}</span>
              </Link>
              <button className="btn btn-outline btn-sm" onClick={handleLogout}>Cerrar sesión</button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
