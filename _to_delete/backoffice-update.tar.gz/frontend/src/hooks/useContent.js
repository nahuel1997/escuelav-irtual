import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { defaultsMap } from '../config/content';

// Trae TODO el contenido editable del sitio de un solo golpe (GET
// /api/content, público): los textos/imágenes/colores por clave, los
// links extra de menú/footer, y el registro de "opciones de botón". Se
// mezcla con los valores por defecto hardcodeados para que la página
// nunca se quede vacía si todavía no se cargó nada desde el admin.
export function useContent() {
  const [state, setState] = useState({ values: defaultsMap(), navLinks: [], buttons: [] });

  useEffect(() => {
    api
      .get('/content', { auth: false })
      .then(({ content: fromApi, navLinks, buttons }) => {
        setState((prev) => {
          const values = { ...prev.values };
          Object.entries(fromApi || {}).forEach(([clave, valor]) => {
            if (valor) values[clave] = valor; // solo pisa si hay algo cargado
          });
          return { values, navLinks: navLinks || [], buttons: buttons || [] };
        });
      })
      .catch(() => {
        // si falla, nos quedamos con los valores por defecto sin romper la página
      });
  }, []);

  return state;
}

// Resuelve qué "Opción N" de botón está asignada a una clave puntual
// (ej: "home.hero.boton_principal") contra el registro de buttons.
export function resolveButton(buttons, valores, clave) {
  const id = valores[clave];
  if (!id) return null;
  return buttons.find((b) => String(b.id) === String(id)) || null;
}
