import { useEffect, useState } from 'react';
import { api } from '../api/client';
import CourseCard from '../components/CourseCard';
import { useContent } from '../hooks/useContent';
import { useSeo } from '../hooks/useSeo';

// Tienda de cursos: catálogo público, no requiere estar logueado para
// verlo (solo para comprar/inscribirse, eso se resuelve en CourseDetail).
// Cada tarjeta de curso es dinámica (una por curso), así que no tiene un
// botón fijo asignable desde "Opciones de botón" — solo título/subtítulo/
// color de fondo y SEO son editables acá.
export default function Store() {
  const { values: content } = useContent();
  useSeo(content, 'tienda', 'Tienda de cursos');

  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    api
      .get('/courses', { auth: false })
      .then((data) => setCourses(data.courses))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <section className="section" style={{ background: content['tienda.color_fondo'] || undefined }}>
      <div className="container">
        <h1>{content['tienda.titulo']}</h1>
        <p className="text-muted">{content['tienda.subtitulo']}</p>

        {loading && <div className="spinner-msg">Cargando cursos…</div>}
        {error && <div className="alert alert-error">{error}</div>}

        {!loading && !error && (
          <div className="grid grid-3" style={{ marginTop: 24 }}>
            {courses.map((c) => (
              <CourseCard key={c.id} course={c} />
            ))}
            {courses.length === 0 && <p className="text-muted">Todavía no hay cursos publicados.</p>}
          </div>
        )}
      </div>
    </section>
  );
}
