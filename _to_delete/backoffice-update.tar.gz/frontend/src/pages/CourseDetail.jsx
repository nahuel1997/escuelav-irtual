import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { useContent, resolveButton } from '../hooks/useContent';
import { useSeo } from '../hooks/useSeo';

function formatPrecio(precio) {
  return new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS', maximumFractionDigits: 0 }).format(precio);
}

export default function CourseDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { values: content, buttons } = useContent();
  useSeo(content, 'curso', 'Curso');
  const botonComprar = resolveButton(buttons, content, 'curso.boton_comprar');
  const colorAcento = content['curso.color_acento'];

  const [course, setCourse] = useState(null);
  const [misCursos, setMisCursos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [comprando, setComprando] = useState(false);
  const [error, setError] = useState('');
  const [ok, setOk] = useState(false);

  useEffect(() => {
    api.get(`/courses/${id}`, { auth: false }).then((d) => setCourse(d.course)).catch((e) => setError(e.message));
    if (user) {
      api.get('/courses/mine').then((d) => setMisCursos(d.courses)).finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [id, user]);

  const yaInscripto = misCursos.some((c) => c.id === Number(id));

  async function comprar() {
    if (!user) return navigate('/ingresar');
    setComprando(true);
    setError('');
    try {
      await api.post(`/courses/${id}/enroll`);
      setOk(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setComprando(false);
    }
  }

  if (loading) return <div className="spinner-msg">Cargando…</div>;
  if (!course) return <div className="container section"><div className="alert alert-error">{error || 'Curso no encontrado'}</div></div>;

  return (
    <section className="section">
      <div className="container" style={{ maxWidth: 720 }}>
        {course.categoria && <span className="badge">{course.categoria}</span>}
        <h1>{course.titulo}</h1>
        <p className="text-muted">{course.descripcion}</p>
        <p style={{ fontSize: '1.4rem', color: colorAcento || 'var(--color-primary)' }}><strong>{formatPrecio(course.precio)}</strong></p>

        {error && <div className="alert alert-error">{error}</div>}
        {ok && <div className="alert alert-success">¡Listo! Ya estás inscripto. Podés entrar al classroom desde "Mis cursos".</div>}

        {ok || yaInscripto ? (
          <Link to="/mis-cursos" className="btn btn-primary">Ir a mis cursos</Link>
        ) : (
          <button
            className="btn btn-accent"
            onClick={comprar}
            disabled={comprando}
            style={botonComprar ? { background: botonComprar.color_fondo, color: botonComprar.color_texto } : undefined}
          >
            {comprando ? 'Procesando pago…' : 'Comprar / Inscribirme'}
          </button>
        )}
        <p className="text-muted" style={{ marginTop: 12, fontSize: '0.85rem' }}>
          * Pago simulado: por ahora no se realiza ningún cobro real.
        </p>
      </div>
    </section>
  );
}
