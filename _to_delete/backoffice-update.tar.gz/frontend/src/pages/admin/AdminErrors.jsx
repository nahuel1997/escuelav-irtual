import { useEffect, useState } from 'react';
import { api } from '../../api/client';

function formatearFecha(iso) {
  return new Date(iso).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

// Registro de errores reales del sistema (5xx), capturados automáticamente
// por el errorHandler central — ver backend/src/middlewares/error.middleware.js.
// A propósito no incluye errores 4xx (permisos, validaciones de negocio):
// esos pasan todo el tiempo en el uso normal y no son "errores de la app".
export default function AdminErrors() {
  const [errores, setErrores] = useState([]);
  const [filtro, setFiltro] = useState({ desde: '', hasta: '' });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  function cargar(f) {
    setLoading(true);
    const params = new URLSearchParams();
    if (f.desde) params.set('desde', f.desde);
    if (f.hasta) params.set('hasta', f.hasta);
    const query = params.toString() ? `?${params.toString()}` : '';
    return api
      .get(`/admin/errores${query}`)
      .then((d) => setErrores(d.errores))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => { cargar(filtro); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  function handleFiltrar(e) {
    e.preventDefault();
    cargar(filtro);
  }

  return (
    <div>
      <h1>Errores</h1>
      <p className="text-muted">Fallas reales de la aplicación (errores 5xx), capturadas automáticamente.</p>

      <form onSubmit={handleFiltrar} className="card" style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap', marginTop: 16 }}>
        <div className="field" style={{ marginBottom: 0 }}>
          <label>Desde</label>
          <input type="date" value={filtro.desde} onChange={(e) => setFiltro({ ...filtro, desde: e.target.value })} />
        </div>
        <div className="field" style={{ marginBottom: 0 }}>
          <label>Hasta</label>
          <input type="date" value={filtro.hasta} onChange={(e) => setFiltro({ ...filtro, hasta: e.target.value })} />
        </div>
        <button className="btn btn-primary btn-sm">Filtrar</button>
      </form>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="card" style={{ overflowX: 'auto', marginTop: 16 }}>
        {loading ? (
          <p className="text-muted">Cargando…</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Status</th>
                <th>Mensaje</th>
                <th>Ruta</th>
                <th>Método</th>
              </tr>
            </thead>
            <tbody>
              {errores.map((e) => (
                <tr key={e.id}>
                  <td>{formatearFecha(e.created_at)}</td>
                  <td><span className="badge badge-danger">{e.status}</span></td>
                  <td>{e.mensaje}</td>
                  <td>{e.ruta || '—'}</td>
                  <td>{e.metodo || '—'}</td>
                </tr>
              ))}
              {errores.length === 0 && (
                <tr><td colSpan={5} className="text-muted">Sin errores registrados en el rango elegido. 🎉</td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
