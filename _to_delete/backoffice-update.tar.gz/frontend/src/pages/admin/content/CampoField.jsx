import { useEffect, useState } from 'react';
import { API_ORIGIN } from '../../../api/client';
import { HEADING_FONTS, BODY_FONTS } from '../../../config/fonts';

// Renderiza UN campo editable, según su tipo (texto/imagen/color/
// seleccion/boton). Lo reutilizan GeneralTab y PageTab para no duplicar
// esta lógica en cada pestaña.
export default function CampoField({ campo, valor, botones, onGuardar, onSubirImagen }) {
  const [local, setLocal] = useState(valor ?? '');
  const [guardando, setGuardando] = useState(false);
  const [subiendo, setSubiendo] = useState(false);
  const [mensaje, setMensaje] = useState('');

  // Si el valor de afuera cambia (ej: recién terminó de cargar desde la
  // API), sincronizamos el buffer local.
  useEffect(() => { setLocal(valor ?? ''); }, [valor]);

  async function guardar(valorAGuardar) {
    setGuardando(true);
    setMensaje('');
    try {
      await onGuardar(valorAGuardar);
      setMensaje('Guardado ✓');
    } catch (err) {
      setMensaje(err.message);
    } finally {
      setGuardando(false);
    }
  }

  async function subir(file) {
    setSubiendo(true);
    setMensaje('');
    try {
      await onSubirImagen(file);
      setMensaje('Imagen actualizada ✓');
    } catch (err) {
      setMensaje(err.message);
    } finally {
      setSubiendo(false);
    }
  }

  return (
    <div>
      <label style={{ fontWeight: 600, fontSize: '0.9rem', display: 'block', marginBottom: 6 }}>{campo.label}</label>

      {campo.tipo === 'texto' && (
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
          {campo.textarea ? (
            <textarea rows={3} style={{ flex: 1 }} value={local} onChange={(e) => setLocal(e.target.value)} />
          ) : (
            <input style={{ flex: 1 }} value={local} onChange={(e) => setLocal(e.target.value)} />
          )}
          <button className="btn btn-primary btn-sm" disabled={guardando} onClick={() => guardar(local)}>
            {guardando ? '...' : 'Guardar'}
          </button>
        </div>
      )}

      {campo.tipo === 'color' && (
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <input type="color" value={local || '#ffffff'} onChange={(e) => setLocal(e.target.value)} style={{ width: 48, height: 38, padding: 2 }} />
          <input style={{ flex: 1, maxWidth: 140 }} value={local} onChange={(e) => setLocal(e.target.value)} placeholder="#rrggbb" />
          <button className="btn btn-primary btn-sm" disabled={guardando} onClick={() => guardar(local)}>
            {guardando ? '...' : 'Guardar'}
          </button>
        </div>
      )}

      {campo.tipo === 'imagen' && (
        <div>
          {valor && (
            <img
              src={valor.startsWith('/uploads') ? `${API_ORIGIN}${valor}` : valor}
              alt={campo.label}
              style={{ maxWidth: 220, borderRadius: 8, display: 'block', marginBottom: 8 }}
            />
          )}
          <input type="file" accept="image/*" onChange={(e) => e.target.files[0] && subir(e.target.files[0])} />
          {subiendo && <p className="text-muted" style={{ fontSize: '0.8rem' }}>Subiendo…</p>}
        </div>
      )}

      {campo.tipo === 'seleccion' && (
        <select
          value={local || campo.default}
          onChange={(e) => { setLocal(e.target.value); guardar(e.target.value); }}
        >
          {(campo.opciones === 'titulos' ? HEADING_FONTS : BODY_FONTS).map((f) => (
            <option key={f.id} value={f.id}>{f.label}</option>
          ))}
        </select>
      )}

      {campo.tipo === 'boton' && (
        <div>
          <select
            value={local || ''}
            onChange={(e) => { setLocal(e.target.value); guardar(e.target.value); }}
          >
            <option value="">Sin asignar (usa el estilo por defecto del sitio)</option>
            {botones.map((b) => <option key={b.id} value={b.id}>{b.nombre}</option>)}
          </select>
          {campo.soloColor && (
            <p className="text-muted" style={{ fontSize: '0.8rem', marginTop: 4 }}>
              Este botón dispara una acción (enviar, comprar, ingresar): de la opción elegida solo se usa el color, el link queda fijo.
            </p>
          )}
          {botones.length === 0 && (
            <p className="text-muted" style={{ fontSize: '0.8rem', marginTop: 4 }}>
              Todavía no cargaste ninguna opción de botón — agregá una en la pestaña "Generales".
            </p>
          )}
        </div>
      )}

      {mensaje && <p className="text-muted" style={{ fontSize: '0.8rem', marginTop: 4 }}>{mensaje}</p>}
    </div>
  );
}
