import { useEffect, useState } from 'react';
import { api } from '../../api/client';

function formatearFecha(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function formatearDuracion(inicio, fin) {
  if (!fin) return null;
  const minutos = Math.round((new Date(fin) - new Date(inicio)) / 60000);
  if (minutos < 60) return `${minutos} min`;
  const horas = Math.floor(minutos / 60);
  const resto = minutos % 60;
  return `${horas} h ${resto} min`;
}

// Registro de inicio/fin de sesión de cada usuario, filtrable por usuario
// y por rango de fechas. Con JWT no hay sesión server-side: "fin" se marca
// cuando el usuario aprieta "Cerrar sesión" (ver AuthContext.logout() y
// POST /api/auth/logout); si cierra la pestaña sin desloguearse, queda
// "Sesión activa" — es una limitación honesta de JWT, no un bug.
export default function AdminLogins() {
  const [usuarios, setUsuarios] = useState([]);
  const [logins, setLogins] = useState([]);
  const [filtro, setFiltro] = useState({ userId: '', desde: '', hasta: '' });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/admin/users?rol=todos').then((d) => setUsuarios(d.users));
    cargar(filtro);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  function cargar(f) {
    setLoading(true);
    const params = new URLSearchParams();
    if (f.userId) params.set('userId', f.userId);
    if (f.desde) params.set('desde', f.desde);
    if (f.hasta) params.set('hasta', f.hasta);
    const query = params.toString() ? `?${params.toString()}` : '';
    return api
      .get(`/admin/logins${query}`)
      .then((d) => setLogins(d.logins))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  function handleFiltrar(e) {
    e.preventDefault();
    cargar(filtro);
  }

  return (
    <div>
      <h1>Registro de logins</h1>
      <p className="text-muted">Cuándo inició y cuándo terminó cada conexión de cada usuario.</p>

      <form onSubmit={handleFiltrar} className="card" style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap', marginTop: 16 }}>
        <div className="field" style={{ marginBottom: 0, minWidth: 220 }}>
          <label>Usuario</label>
          <select value={filtro.userId} onChange={(e) => setFiltro({ ...filtro, userId: e.target.value })}>
            <option value="">Todos los usuarios</option>
            {usuarios.map((u) => (
              <option key={u.id} value={u.id}>{u.nombre} {u.apellido} ({u.rol})</option>
            ))}
          </select>
        </div>
        <div className="field" style={{ marginBottom: 0 }}>
          <label>Desde</label>
          <input type="date" value={filtro.desde} onChange={(e) => setFiltro({ ...filtro, desde: e.target.value })} />
        </div>
        <div className="field" style={{ marginBottom: 0 }}>
          <label>Hasta</label>
          <input type="date" value={filtro.hasta} onChange={(e) => setFiltro({ ...filtro, hasta: e.target.value })} />
        </div>
        <button className="btn btn-primary btn-sm">Filtrar</button>
      </form>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="card" style={{ overflowX: 'auto', marginTop: 16 }}>
        {loading ? (
          <p className="text-muted">Cargando…</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Usuario</th>
                <th>Rol</th>
                <th>Inicio</th>
                <th>Fin</th>
                <th>Duración</th>
              </tr>
            </thead>
            <tbody>
              {logins.map((l) => {
                const duracion = formatearDuracion(l.login_at, l.logout_at);
                return (
                  <tr key={l.id}>
                    <td>{l.nombre} {l.apellido} <span className="text-muted">({l.email})</span></td>
                    <td><span className="badge">{l.rol}</span></td>
                    <td>{formatearFecha(l.login_at)}</td>
                    <td>
                      {l.logout_at ? formatearFecha(l.logout_at) : <span className="badge badge-success">Sesión activa</span>}
                    </td>
                    <td>{duracion || '—'}</td>
                  </tr>
                );
              })}
              {logins.length === 0 && (
                <tr><td colSpan={5} className="text-muted">No hay conexiones que coincidan con el filtro.</td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
