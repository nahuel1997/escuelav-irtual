const db = require('../config/db');

function create(userId) {
  return db('login_logs').insert({ user_id: userId, login_at: db.fn.now() });
}

// Cierra la sesión abierta más reciente de ese usuario (logout_at null).
// Si no hay ninguna abierta (ej: tocó "cerrar sesión" dos veces, o nunca
// hubo login_log porque el token es viejo), no hace nada.
async function closeOpenSession(userId) {
  const abierta = await db('login_logs')
    .where({ user_id: userId })
    .whereNull('logout_at')
    .orderBy('login_at', 'desc')
    .first();
  if (!abierta) return 0;
  return db('login_logs').where({ id: abierta.id }).update({ logout_at: db.fn.now() });
}

// Registro para el admin: usuario, cuándo entró, cuándo salió (o "sigue
// activa" si logout_at es null), filtrable por usuario y rango de fechas.
function listAll({ userId, desde, hasta } = {}) {
  const query = db('login_logs as l')
    .join('users as u', 'u.id', 'l.user_id')
    .select(
      'l.id',
      'l.user_id',
      'l.login_at',
      'l.logout_at',
      'u.nombre',
      'u.apellido',
      'u.email',
      'u.rol'
    )
    .orderBy('l.login_at', 'desc')
    .limit(500);
  if (userId) query.where('l.user_id', userId);
  if (desde) query.where('l.login_at', '>=', desde);
  if (hasta) query.where('l.login_at', '<=', hasta);
  return query;
}

module.exports = { create, closeOpenSession, listAll };
