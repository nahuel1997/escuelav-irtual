// Capa de acceso a datos para "users". Los controllers no escriben SQL/knex
// directamente: pasan siempre por acá, así si el día de mañana cambia el
// motor de base de datos (sqlite -> postgres) o alguna query se optimiza,
// se toca en un solo lugar.
const db = require('../config/db');

const PUBLIC_FIELDS = ['id', 'nombre', 'apellido', 'email', 'rol', 'avatar_url', 'created_at'];

function findByEmail(email) {
  return db('users').where({ email }).first();
}

function findById(id) {
  return db('users').where({ id }).first();
}

function findPublicById(id) {
  return db('users').select(PUBLIC_FIELDS).where({ id }).first();
}

async function create({ nombre, apellido, email, password_hash, rol }) {
  const [id] = await db('users').insert({ nombre, apellido, email, password_hash, rol });
  return findPublicById(id);
}

function updateProfile(id, { nombre, apellido, avatar_url }) {
  const patch = {};
  if (nombre !== undefined) patch.nombre = nombre;
  if (apellido !== undefined) patch.apellido = apellido;
  if (avatar_url !== undefined) patch.avatar_url = avatar_url;
  return db('users').where({ id }).update(patch);
}

// Usado por el panel de admin: listar profesores (o cualquier rol) para
// asignarlos a cursos o simplemente para mostrarlos en una tabla.
function listByRole(rol) {
  return db('users').select(PUBLIC_FIELDS).where({ rol }).orderBy('nombre');
}

function countByRole(rol) {
  return db('users').where({ rol }).count({ count: '*' }).first();
}

// Usado por el filtro de usuario del registro de logins en el admin: ahí
// hace falta elegir entre cualquier usuario, sin importar el rol.
function listAll() {
  return db('users').select(PUBLIC_FIELDS).orderBy('nombre');
}

module.exports = {
  findByEmail,
  findById,
  findPublicById,
  create,
  updateProfile,
  listByRole,
  countByRole,
  listAll,
  PUBLIC_FIELDS,
};
