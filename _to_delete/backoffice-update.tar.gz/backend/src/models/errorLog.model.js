const db = require('../config/db');

function create({ status, mensaje, ruta, metodo, user_id }) {
  return db('error_logs').insert({ status, mensaje, ruta, metodo, user_id: user_id || null });
}

// Registro para el admin, más reciente primero. Filtro opcional por rango
// de fechas (desde/hasta, formato ISO). Se limita a 300 filas: es un log
// de errores del sistema, no se espera que crezca sin control salvo que
// algo esté realmente roto (y en ese caso, lo primero es arreglarlo).
function listAll({ desde, hasta } = {}) {
  const query = db('error_logs').select('*').orderBy('created_at', 'desc').limit(300);
  if (desde) query.where('created_at', '>=', desde);
  if (hasta) query.where('created_at', '<=', hasta);
  return query;
}

module.exports = { create, listAll };
