const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const env = require('../config/env');
const userModel = require('../models/user.model');
const loginLogModel = require('../models/loginLog.model');
const { asyncHandler, AppError } = require('../middlewares/error.middleware');

function signToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, rol: user.rol, nombre: user.nombre },
    env.JWT_SECRET,
    { expiresIn: env.JWT_EXPIRES_IN }
  );
}

const register = asyncHandler(async (req, res) => {
  const { nombre, apellido, email, password } = req.body;

  if (!nombre || !apellido || !email || !password) {
    throw new AppError('Faltan campos obligatorios (nombre, apellido, email, password)', 400);
  }
  if (password.length < 6) {
    throw new AppError('La contraseña debe tener al menos 6 caracteres', 400);
  }
  // El registro público SIEMPRE crea una cuenta de alumno. Las cuentas de
  // profesor y admin se crean únicamente desde el panel de administración
  // (POST /api/admin/users, protegido por rol admin) — ignoramos a
  // propósito cualquier "rol" que venga en el body para que nadie pueda
  // auto-asignarse profesor/admin mandando el campo a mano.
  const rolFinal = 'alumno';

  const existente = await userModel.findByEmail(email.toLowerCase().trim());
  if (existente) {
    throw new AppError('Ya existe una cuenta con ese email', 409);
  }

  const password_hash = await bcrypt.hash(password, 10);
  const user = await userModel.create({
    nombre: nombre.trim(),
    apellido: apellido.trim(),
    email: email.toLowerCase().trim(),
    password_hash,
    rol: rolFinal,
  });

  const token = signToken(user);
  await loginLogModel.create(user.id);
  res.status(201).json({ token, user });
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    throw new AppError('Faltan email y/o password', 400);
  }

  const user = await userModel.findByEmail(email.toLowerCase().trim());
  if (!user) {
    throw new AppError('Email o contraseña incorrectos', 401);
  }

  const passwordOk = await bcrypt.compare(password, user.password_hash);
  if (!passwordOk) {
    throw new AppError('Email o contraseña incorrectos', 401);
  }

  const token = signToken(user);
  await loginLogModel.create(user.id);
  const { password_hash, ...userPublico } = user;
  res.json({ token, user: userPublico });
});

const me = asyncHandler(async (req, res) => {
  const user = await userModel.findPublicById(req.user.id);
  if (!user) throw new AppError('Usuario no encontrado', 404);
  res.json({ user });
});

// Con JWT no hay sesión server-side para "cerrar": lo que hacemos acá es
// marcar en login_logs cuándo terminó esta conexión, para que el registro
// de logins del admin pueda mostrar inicio y fin. El frontend llama a este
// endpoint antes de descartar el token (ver AuthContext.logout()).
const logout = asyncHandler(async (req, res) => {
  await loginLogModel.closeOpenSession(req.user.id);
  res.json({ ok: true });
});

module.exports = { register, login, me, logout };
