const bcrypt = require('bcryptjs');
const adminModel = require('../models/admin.model');
const userModel = require('../models/user.model');
const courseModel = require('../models/course.model');
const contentModel = require('../models/content.model');
const calendarModel = require('../models/calendarEvent.model');
const navLinkModel = require('../models/navLink.model');
const buttonOptionModel = require('../models/buttonOption.model');
const errorLogModel = require('../models/errorLog.model');
const loginLogModel = require('../models/loginLog.model');
const { esRolValido } = require('../utils/roles');
const { esTipoValido } = require('../utils/contentTipos');
const { asyncHandler, AppError } = require('../middlewares/error.middleware');

const getDashboard = asyncHandler(async (req, res) => {
  const data = await adminModel.dashboard();
  res.json(data);
});

// --- Usuarios (crear profesores/admins — no hay registro público para esto) ---

const listUsersByRole = asyncHandler(async (req, res) => {
  // "todos" es un caso especial para el filtro de usuario del registro de
  // logins, que necesita elegir entre cualquier cuenta sin importar el rol.
  if (req.query.rol === 'todos') {
    const users = await userModel.listAll();
    return res.json({ users });
  }
  const rol = req.query.rol || 'profesor';
  if (!esRolValido(rol)) throw new AppError('Rol inválido', 400);
  const users = await userModel.listByRole(rol);
  res.json({ users });
});

const createUser = asyncHandler(async (req, res) => {
  const { nombre, apellido, email, password, rol } = req.body;
  if (!nombre || !apellido || !email || !password || !rol) {
    throw new AppError('Faltan campos obligatorios (nombre, apellido, email, password, rol)', 400);
  }
  if (!esRolValido(rol)) throw new AppError('Rol inválido', 400);
  if (password.length < 6) throw new AppError('La contraseña debe tener al menos 6 caracteres', 400);

  const existente = await userModel.findByEmail(email.toLowerCase().trim());
  if (existente) throw new AppError('Ya existe una cuenta con ese email', 409);

  const password_hash = await bcrypt.hash(password, 10);
  const user = await userModel.create({
    nombre: nombre.trim(),
    apellido: apellido.trim(),
    email: email.toLowerCase().trim(),
    password_hash,
    rol,
  });
  res.status(201).json({ user });
});

// --- Cursos (el admin puede crear/editar cualquiera, asignando profesor) ---

const listCourses = asyncHandler(async (req, res) => {
  const courses = await courseModel.listAll();
  res.json({ courses });
});

const createCourse = asyncHandler(async (req, res) => {
  const { titulo, descripcion, precio, categoria, imagen_url, profesor_id } = req.body;
  if (!titulo || !descripcion) throw new AppError('Faltan título y/o descripción del curso', 400);
  if (!profesor_id) throw new AppError('Falta asignar un profesor al curso', 400);

  const profesor = await userModel.findById(profesor_id);
  if (!profesor || profesor.rol !== 'profesor') {
    throw new AppError('El profesor seleccionado no existe o no tiene rol de profesor', 400);
  }

  const [id] = await courseModel.create({
    titulo,
    descripcion,
    precio: precio || 0,
    categoria,
    imagen_url,
    profesor_id,
  });
  const course = await courseModel.findById(id);
  res.status(201).json({ course });
});

const updateCourse = asyncHandler(async (req, res) => {
  const course = await courseModel.findById(req.params.id);
  if (!course) throw new AppError('Curso no encontrado', 404);

  const { titulo, descripcion, precio, categoria, imagen_url, profesor_id } = req.body;
  const patch = {};
  if (titulo !== undefined) patch.titulo = titulo;
  if (descripcion !== undefined) patch.descripcion = descripcion;
  if (precio !== undefined) patch.precio = precio;
  if (categoria !== undefined) patch.categoria = categoria;
  if (imagen_url !== undefined) patch.imagen_url = imagen_url;

  if (profesor_id !== undefined) {
    const profesor = await userModel.findById(profesor_id);
    if (!profesor || profesor.rol !== 'profesor') {
      throw new AppError('El profesor seleccionado no existe o no tiene rol de profesor', 400);
    }
    patch.profesor_id = profesor_id;
  }

  await courseModel.update(req.params.id, patch);
  const actualizado = await courseModel.findById(req.params.id);
  res.json({ course: actualizado });
});

// --- Contenido del sitio (textos e imágenes editables) ---

const listContent = asyncHandler(async (req, res) => {
  const content = await contentModel.listAll();
  res.json({ content });
});

const updateContent = asyncHandler(async (req, res) => {
  const { clave } = req.params;
  const { tipo, valor } = req.body;
  if (valor === undefined) throw new AppError('Falta el valor', 400);
  if (tipo !== undefined && !esTipoValido(tipo)) throw new AppError('Tipo de contenido inválido', 400);
  const actualizado = await contentModel.upsert(clave, { tipo, valor });
  res.json({ content: actualizado });
});

// --- Subida de imágenes (portadas de curso y contenido del sitio) ---

const uploadImage = asyncHandler(async (req, res) => {
  if (!req.file) throw new AppError('Falta el archivo de imagen', 400);
  const url = `/uploads/imagenes/${req.file.filename}`;
  res.status(201).json({ url });
});

// --- Calendario (registro de todos los turnos alumno-profesor) ---

const listCalendarEvents = asyncHandler(async (req, res) => {
  const { estado } = req.query;
  const eventos = await calendarModel.listAll({ estado });
  res.json({ eventos });
});

// --- Links de menú/footer (además de la navegación funcional del código) ---

const listNavLinks = asyncHandler(async (req, res) => {
  const links = await navLinkModel.listAll();
  res.json({ links });
});

const createNavLink = asyncHandler(async (req, res) => {
  const { ubicacion, texto, url, orden } = req.body;
  if (!['menu', 'footer'].includes(ubicacion)) throw new AppError('Ubicación inválida (debe ser "menu" o "footer")', 400);
  if (!texto || !url) throw new AppError('Faltan el texto y/o el link', 400);
  const [id] = await navLinkModel.create({ ubicacion, texto, url, orden: orden || 0 });
  res.status(201).json({ link: await navLinkModel.findById(id) });
});

const updateNavLink = asyncHandler(async (req, res) => {
  const existente = await navLinkModel.findById(req.params.id);
  if (!existente) throw new AppError('Link no encontrado', 404);
  const { ubicacion, texto, url, orden } = req.body;
  if (ubicacion !== undefined && !['menu', 'footer'].includes(ubicacion)) {
    throw new AppError('Ubicación inválida (debe ser "menu" o "footer")', 400);
  }
  const patch = {};
  if (ubicacion !== undefined) patch.ubicacion = ubicacion;
  if (texto !== undefined) patch.texto = texto;
  if (url !== undefined) patch.url = url;
  if (orden !== undefined) patch.orden = orden;
  await navLinkModel.update(req.params.id, patch);
  res.json({ link: await navLinkModel.findById(req.params.id) });
});

const deleteNavLink = asyncHandler(async (req, res) => {
  const existente = await navLinkModel.findById(req.params.id);
  if (!existente) throw new AppError('Link no encontrado', 404);
  await navLinkModel.remove(req.params.id);
  res.json({ ok: true });
});

// --- Registro de botones ("Opción N") reutilizable en cualquier página ---

const listButtonOptions = asyncHandler(async (req, res) => {
  const opciones = await buttonOptionModel.listAll();
  res.json({ opciones });
});

const createButtonOption = asyncHandler(async (req, res) => {
  const { color_fondo, color_texto, link } = req.body;
  if (!link) throw new AppError('Falta el link de destino', 400);
  const [id] = await buttonOptionModel.create({
    color_fondo: color_fondo || '#16324a',
    color_texto: color_texto || '#ffffff',
    link,
  });
  res.status(201).json({ opcion: await buttonOptionModel.findById(id) });
});

const updateButtonOption = asyncHandler(async (req, res) => {
  const existente = await buttonOptionModel.findById(req.params.id);
  if (!existente) throw new AppError('Opción de botón no encontrada', 404);
  const { color_fondo, color_texto, link } = req.body;
  const patch = {};
  if (color_fondo !== undefined) patch.color_fondo = color_fondo;
  if (color_texto !== undefined) patch.color_texto = color_texto;
  if (link !== undefined) patch.link = link;
  await buttonOptionModel.update(req.params.id, patch);
  res.json({ opcion: await buttonOptionModel.findById(req.params.id) });
});

const deleteButtonOption = asyncHandler(async (req, res) => {
  const existente = await buttonOptionModel.findById(req.params.id);
  if (!existente) throw new AppError('Opción de botón no encontrada', 404);
  await buttonOptionModel.remove(req.params.id);
  res.json({ ok: true });
});

// --- Errores del sistema (solo lectura) ---

const listErrorLogs = asyncHandler(async (req, res) => {
  const { desde, hasta } = req.query;
  const errores = await errorLogModel.listAll({ desde, hasta });
  res.json({ errores });
});

// --- Registro de logins (solo lectura, filtrable) ---

const listLoginLogs = asyncHandler(async (req, res) => {
  const { userId, desde, hasta } = req.query;
  const logins = await loginLogModel.listAll({ userId, desde, hasta });
  res.json({ logins });
});

module.exports = {
  getDashboard,
  listUsersByRole,
  createUser,
  listCourses,
  createCourse,
  updateCourse,
  listContent,
  updateContent,
  uploadImage,
  listCalendarEvents,
  listNavLinks,
  createNavLink,
  updateNavLink,
  deleteNavLink,
  listButtonOptions,
  createButtonOption,
  updateButtonOption,
  deleteButtonOption,
  listErrorLogs,
  listLoginLogs,
};
