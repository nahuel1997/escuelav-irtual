const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin.controller');
const { requireAuth, requireRole } = require('../middlewares/auth.middleware');
const { uploadImagen } = require('../middlewares/upload.middleware');

// Todo /api/admin/* requiere estar logueado Y tener rol admin.
router.use(requireAuth, requireRole('admin'));

router.get('/dashboard', adminController.getDashboard);

router.get('/users', adminController.listUsersByRole);
router.post('/users', adminController.createUser);

router.get('/courses', adminController.listCourses);
router.post('/courses', adminController.createCourse);
router.put('/courses/:id', adminController.updateCourse);

router.get('/content', adminController.listContent);
router.put('/content/:clave', adminController.updateContent);

router.post('/upload-imagen', uploadImagen, adminController.uploadImage);

router.get('/calendario', adminController.listCalendarEvents);

router.get('/nav-links', adminController.listNavLinks);
router.post('/nav-links', adminController.createNavLink);
router.put('/nav-links/:id', adminController.updateNavLink);
router.delete('/nav-links/:id', adminController.deleteNavLink);

router.get('/botones', adminController.listButtonOptions);
router.post('/botones', adminController.createButtonOption);
router.put('/botones/:id', adminController.updateButtonOption);
router.delete('/botones/:id', adminController.deleteButtonOption);

router.get('/errores', adminController.listErrorLogs);

router.get('/logins', adminController.listLoginLogs);

module.exports = router;
