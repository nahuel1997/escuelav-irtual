// Manejo centralizado de errores. Cualquier controller puede simplemente
// hacer `next(error)` (o tirar un throw dentro de un async-handler) y esto
// se encarga de loguear y responder con un formato consistente.
function notFoundHandler(req, res, next) {
  res.status(404).json({ error: 'Recurso no encontrado', path: req.originalUrl });
}

function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  const status = err.status || 500;
  if (status >= 500) {
    console.error('[ERROR]', err);
    // Solo persistimos errores 5xx (fallas reales del sistema), no 4xx de
    // uso normal (permisos, validaciones de negocio) — eso llenaría el
    // registro de ruido sin aportar nada útil para "Errores" en el admin.
    // Best-effort: si esto falla, no debe tirar abajo la respuesta.
    // require() adentro de la función para evitar dependencia circular con
    // config/db.js al arrancar la app.
    try {
      const errorLogModel = require('../models/errorLog.model');
      errorLogModel
        .create({
          status,
          mensaje: (err.message || 'Error interno del servidor').slice(0, 500),
          ruta: req.originalUrl,
          metodo: req.method,
          user_id: req.user?.id,
        })
        .catch(() => {});
    } catch (_e) {
      // noop
    }
  }
  res.status(status).json({
    error: err.publicMessage || err.message || 'Error interno del servidor',
  });
}

// Helper para no repetir try/catch en cada controller async.
function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

class AppError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
    this.publicMessage = message;
  }
}

module.exports = { notFoundHandler, errorHandler, asyncHandler, AppError };
